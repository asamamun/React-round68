import { useState, useEffect } from 'react'
import './App.css'
import Product from './Product';
import Cart from './Cart';
import useStorage from './hooks/useStorage';

//custom hook useStorageState
const useStorageState = (initialState) => {
  const [searchTerm, setSearchTerm] = useState(
    localStorage.getItem('search') || initialState
  );//end of use state
  useEffect(() => {
    localStorage.setItem('search', searchTerm);
  }, [searchTerm]);//end of use effect
  return [searchTerm, setSearchTerm];
};

function App() {
  const [searchTerm, setSearchTerm] = useStorageState("JS");
  const [cart, setCart] = useStorage('shoppingCart', []);

  return (
    <div className="app">
      <header className="app-header">
        <h1>🛍️ Shopping Store</h1>
        <nav className="nav-buttons">
          <button className="nav-btn active">Products</button>
          <button className="nav-btn">Cart ({cart.reduce((total, item) => total + item.quantity, 0)})</button>
        </nav>
      </header>
      
      <main className="main-content">
        <h1>Checking React Custom Hook: {searchTerm}</h1>
        <input type="text" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        <hr/>
        <marquee><h3>Products component with cart state start</h3></marquee>
        <Product cart={cart} setCart={setCart} />
        <marquee><h3>Products component with cart state end</h3></marquee>
        <hr/>
        <marquee><h3>Cart component with cart state start</h3></marquee>
        <Cart cart={cart} setCart={setCart} />
        <marquee><h3>Cart component with cart state end</h3></marquee>
      </main>
    </div>
  )
}

export default App
