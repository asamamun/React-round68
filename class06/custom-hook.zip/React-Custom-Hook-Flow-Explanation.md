# React Custom Hook এবং State Flow ব্যাখ্যা (বাংলায়)

## 📚 সূচিপত্র
1. [Custom Hook কী?](#custom-hook-ক)
2. [useStorage Hook কিভাবে কাজ করে?](#usestorage-hook-কভাবে-কাজ-করে)
3. [App Component থেকে State Flow](#app-component-থেকে-state-flow)
4. [Product Component এ Cart State ব্যবহার](#product-component-এ-cart-state-বযবহর)
5. [Cart Component এ State Management](#cart-component-এ-state-management)
6. [পুরো Flow Chart](#পরো-flow-chart)

---

## 🎯 Custom Hook কী?

**Custom Hook** হলো React এর একটি ফিচার যেটি আপনাকে আপনার component logic কে পুনরায় ব্যবহার করতে দেয়।

### নিয়মাবলী:
- Custom Hook এর নাম অবশ্যই `use` দিয়ে শুরু হতে হবে
- এটি React Hook ব্যবহার করতে পারে (useState, useEffect, ইত্যাদি)
- Component এর মতোই এটি জাভাস্ক্রিপ্ট ফাংশন

---

## 🔧 useStorage Hook কিভাবে কাজ করে?

```javascript
const useStorage = (key, initialValue) => {
  // ১. State তৈরি করা হচ্ছে
  const [storedValue, setStoredValue] = useState(() => {
    try {
      // ২. localStorage থেকে value পড়া
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  // ৩. Value সেট করার ফাংশন
  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore); // React state update
      window.localStorage.setItem(key, JSON.stringify(valueToStore)); // localStorage update
    } catch (error) {
      console.error(`Error setting localStorage key "${key}":`, error);
    }
  };

  return [storedValue, setValue]; // ৪. State এবং setter function return
};
```

### ধাপে ধাপে ব্যাখ্যা:

**ধাপ ১:** `useState` দিয়ে একটি state তৈরি করা হয়
**ধাপ ২:** localStorage থেকে পূর্ববর্তী value পড়া হয়, যদি না থাকে তবে `initialValue` ব্যবহার করা হয়
**ধাপ ৩:** `setValue` ফাংশন দুটি কাজ করে:
- React state update করে
- localStorage এ সেভ করে
**ধাপ ৪:** State value এবং setter function return করে

---

## 🏠 App Component থেকে State Flow

```javascript
function App() {
  // ১. useStorage hook ব্যবহার করে cart state তৈরি
  const [cart, setCart] = useStorage('shoppingCart', []);
  
  // cart = [] (initial value)
  // setCart = function to update cart
  
  return (
    <div className="app">
      {/* ২. Product component এ props হিসেবে cart এবং setCart পাঠানো */}
      <Product cart={cart} setCart={setCart} />
      
      {/* ৩. Cart component এ একই props পাঠানো */}
      <Cart cart={cart} setCart={setCart} />
    </div>
  );
}
```

### State Flow ব্যাখ্যা:

1. **`useStorage('shoppingCart', [])`** কল করা হয়
2. **`cart`** = current cart items array
3. **`setCart`** = function to update cart (এটি localStorage ও update করবে)
4. দুটি component এই একই state শেয়ার করে

---

## 🛍️ Product Component এ Cart State ব্যবহার

```javascript
const Product = ({ cart, setCart }) => {
  // Props হিসেবে পাওয়া:
  // cart = current cart items from App component
  // setCart = function to update cart from App component

  const addToCart = (product) => {
    setCart(prevCart => { // App component এর setCart ব্যবহার
      const existingItem = prevCart.find(item => item.id === product.id);
      
      if (existingItem) {
        // যদি item আগে থেকেই থাকে, quantity বাড়ানো
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        // নতুন item যোগ করা
        return [...prevCart, { ...product, quantity: 1 }];
      }
    });
  };
}
```

### Product Component এর কাজ:

1. **Props গ্রহণ:** `cart` এবং `setCart` App component থেকে পায়
2. **Add to Cart:** যখন কোনো product add করা হয়:
   - `setCart` কল করে
   - Previous cart এর উপর ভিত্তি করে নতুন cart তৈরি করে
   - `useStorage` hook স্বয়ংক্রিয়ভাবে localStorage এ সেভ করে

---

## 🛒 Cart Component এ State Management

```javascript
const Cart = ({ cart, setCart }) => {
  // Props হিসেবে পাওয়া:
  // cart = current cart items from App component
  // setCart = function to update cart from App component

  const updateQuantity = (id, newQuantity) => {
    if (newQuantity === 0) {
      // Item সম্পূর্ণ মুছে ফেলা
      setCart(prevCart => prevCart.filter(item => item.id !== id));
    } else {
      // Quantity update করা
      setCart(prevCart =>
        prevCart.map(item =>
          item.id === id ? { ...item, quantity: newQuantity } : item
        )
      );
    }
  };

  const calculateGrandTotal = () => {
    // useEffect ছাড়াই automatic calculation
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2);
  };
}
```

### Cart Component এর কাজ:

1. **Props গ্রহণ:** একই `cart` এবং `setCart` পায়
2. **Quantity Update:** যখন quantity change হয়:
   - `setCart` কল করে App component এর state update করে
   - `useStorage` hook localStorage ও update করে
3. **Grand Total:** প্রতিবার `cart` change হলে React স্বয়ংক্রিয়ভাবে component re-render করে

---

## 🔄 পুরো Flow Chart

```
🏠 App Component
   |
   ├── const [cart, setCart] = useStorage('shoppingCart', [])
   |       |
   |       ├── cart: [] (initial state)
   |       └── setCart: function (updates localStorage)
   |
   ├── 🛍️ Product Component
   |       |
   |       ├── Props: { cart, setCart }
   |       ├── addToCart(product) → setCart([...])
   |       └── যখন add করা হয়:
   |           1. setCart কল করে
   |           2. useStorage localStorage update করে
   |           3. React re-render করে সব component
   |
   └── 🛒 Cart Component
           |
           ├── Props: { cart, setCart }
           ├── updateQuantity(id, qty) → setCart([...])
           ├── calculateGrandTotal() → cart.reduce(...)
           └── যখন quantity change হয়:
               1. setCart কল করে
               2. useStorage localStorage update করে
               3. React re-render করে Cart component
               4. Grand total স্বয়ংক্রিয়ভাবে recalculate হয়
```

---

## 💡 মূল পয়েন্টসমূহ

### ১. **Single Source of Truth**
- শুধুমাত্র App component এর `cart` state হলো source of truth
- অন্য সব component এই state কে props হিসেবে পায়

### ২. **Lifting State Up**
- State কে child component থেকে parent component এ তোলা হয়েছে
- Parent component state manage করে এবং children গুলোকে props দেয়

### ৩. **Custom Hook Benefits**
- Logic পুনরায় ব্যবহার করা যায়
- localStorage management সহজ হয়
- Code clean এবং maintainable থাকে

### ৪. **Automatic Re-render**
- যখনই `setCart` কল করা হয়, React স্বয়ংক্রিয়ভাবে:
  - State update করে
  - localStorage এ সেভ করে
  - সব component re-render করে

### ৫. **No useEffect Needed for Grand Total**
- `calculateGrandTotal()` ফাংশনটি প্রতিবার component render হলে কল হয়
- যেহেতু `cart` dependency হিসেবে আছে, তাই সবসময় latest value দেখায়

---

## 🎯 সারসংক্ষেপ

এই architecture টি React এর **prop drilling** এবং **state lifting** concept এর একটি উত্তম উদাহরণ। Custom hook ব্যবহার করে আমরা localStorage management কে সহজ এবং reusable করেছি, এবং single source of truth maintain করেছি।
