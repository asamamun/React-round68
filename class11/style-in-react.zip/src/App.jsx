import appstyles from './App.module.css';
const App = () => {
  
  return <div className={appstyles.mainapp}>
    <h3 className={appstyles.big}>My App</h3>
    <h3 className={appstyles.small}>My App</h3>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam, odio voluptate asperiores nisi eaque earum vel in cupiditate id repudiandae veritatis error ducimus. Reprehenderit ullam, et ad aut sunt a!</p>
    <p className="para">11 Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam, odio voluptate asperiores nisi eaque earum vel in cupiditate id repudiandae veritatis error ducimus. Reprehenderit ullam, et ad aut sunt a!</p>
    <h3>how to apply multiple class using module css</h3>
    <input type="text" className={`${appstyles.greenborder} ${appstyles.padding5} ${appstyles.margin5}`} />
    <input type="text" className={`${appstyles.greenborder} ${appstyles.padding5} ${appstyles.margin5}`} />
    <input type="text" className={`${appstyles.greenborder} ${appstyles.padding5} ${appstyles.margin5}`} />
  </div>
}
export default App
