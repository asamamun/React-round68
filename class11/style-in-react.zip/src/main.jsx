import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import App2 from './App2.jsx'
import Shad from './Shad'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
    <hr />
    <App2/>
    <hr />
    <Shad/>
  </StrictMode>,
)
