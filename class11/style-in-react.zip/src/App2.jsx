import styled from 'styled-components';
const StyledContainer = styled.div`
height: 20vw;
padding: 20px;
background: #83a4d4;
background: linear-gradient(to left, #b6fbff, #83a4d4);
color: #171212;
`;
const StyledHeadlinePrimary = styled.h3`
font-size: 48px;
font-weight: 300;
letter-spacing: 2px;
text-transform: uppercase;
text-align: center;
`;
const App2 = () => {
  return <StyledContainer>
  <mark>I have not imported App.css here but its styles are applied to the elements. </mark>
  <StyledHeadlinePrimary>My App</StyledHeadlinePrimary>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam, odio voluptate asperiores nisi eaque earum vel in cupiditate id repudiandae veritatis error ducimus. Reprehenderit ullam, et ad aut sunt a!</p>
  <p className="para">Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam, odio voluptate asperiores nisi eaque earum vel in cupiditate id repudiandae veritatis error ducimus. Reprehenderit ullam, et ad aut sunt a!</p>
  </StyledContainer>
}
export default App2
