import { Button } from "@/components/ui/button"

const Shad = () => {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-foreground">Shadcn Button Examples</h1>
          <p className="text-muted-foreground">Comprehensive showcase of button variants, sizes, and states</p>
        </div>

        {/* Section 1: Button Variants */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Button Variants</h2>
          <div className="flex flex-wrap gap-4 items-center">
            <Button variant="default">Default</Button>
            <Button variant="secondary">Secondary</Button>
            <Button variant="destructive">Destructive</Button>
            <Button variant="outline">Outline</Button>
            <Button variant="ghost">Ghost</Button>
            <Button variant="link">Link</Button>
          </div>
        </section>

        {/* Section 2: Button Sizes */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Button Sizes</h2>
          <div className="flex flex-wrap gap-4 items-center">
            <Button size="xs">XS Button</Button>
            <Button size="sm">Small</Button>
            <Button size="default">Default</Button>
            <Button size="lg">Large Button</Button>
          </div>
        </section>

        {/* Section 3: Icon Buttons */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Icon Buttons</h2>
          <div className="flex flex-wrap gap-4 items-center">
            <Button size="icon-xs">📌</Button>
            <Button size="icon-sm">⭐</Button>
            <Button size="icon">❤️</Button>
            <Button size="icon-lg">🚀</Button>
            <button>⭐</button>
          </div>
        </section>

        {/* Section 4: Button States */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Button States</h2>
          <div className="flex flex-wrap gap-4 items-center">
            <Button>Normal</Button>
            <Button disabled>Disabled</Button>
            <Button className="cursor-not-allowed opacity-50">Loading...</Button>
          </div>
        </section>

        {/* Section 5: Variants + Sizes Combination */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Variant + Size Combinations</h2>
          
          <div className="space-y-3">
            <div className="flex flex-wrap gap-4 items-center">
              <span className="text-sm text-muted-foreground w-24">Default:</span>
              <Button variant="default" size="xs">XS</Button>
              <Button variant="default" size="sm">SM</Button>
              <Button variant="default" size="default">Default</Button>
              <Button variant="default" size="lg">LG</Button>
            </div>
            
            <div className="flex flex-wrap gap-4 items-center">
              <span className="text-sm text-muted-foreground w-24">Secondary:</span>
              <Button variant="secondary" size="xs">XS</Button>
              <Button variant="secondary" size="sm">SM</Button>
              <Button variant="secondary" size="default">Default</Button>
              <Button variant="secondary" size="lg">LG</Button>
            </div>
            
            <div className="flex flex-wrap gap-4 items-center">
              <span className="text-sm text-muted-foreground w-24">Destructive:</span>
              <Button variant="destructive" size="xs">XS</Button>
              <Button variant="destructive" size="sm">SM</Button>
              <Button variant="destructive" size="default">Default</Button>
              <Button variant="destructive" size="lg">LG</Button>
            </div>
            
            <div className="flex flex-wrap gap-4 items-center">
              <span className="text-sm text-muted-foreground w-24">Outline:</span>
              <Button variant="outline" size="xs">XS</Button>
              <Button variant="outline" size="sm">SM</Button>
              <Button variant="outline" size="default">Default</Button>
              <Button variant="outline" size="lg">LG</Button>
            </div>
            
            <div className="flex flex-wrap gap-4 items-center">
              <span className="text-sm text-muted-foreground w-24">Ghost:</span>
              <Button variant="ghost" size="xs">XS</Button>
              <Button variant="ghost" size="sm">SM</Button>
              <Button variant="ghost" size="default">Default</Button>
              <Button variant="ghost" size="lg">LG</Button>
            </div>
          </div>
        </section>

        {/* Section 6: Practical Use Cases */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Practical Use Cases</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Form Actions */}
            <div className="space-y-3 p-4 border rounded-lg">
              <h3 className="font-medium">Form Actions</h3>
              <div className="flex gap-2">
                <Button variant="outline">Cancel</Button>
                <Button>Submit</Button>
              </div>
            </div>

            {/* Delete Confirmation */}
            <div className="space-y-3 p-4 border rounded-lg">
              <h3 className="font-medium">Delete Action</h3>
              <div className="flex gap-2">
                <Button variant="outline">Keep</Button>
                <Button variant="destructive">Delete</Button>
              </div>
            </div>

            {/* Navigation */}
            <div className="space-y-3 p-4 border rounded-lg">
              <h3 className="font-medium">Navigation</h3>
              <div className="flex gap-2">
                <Button variant="ghost">← Back</Button>
                <Button variant="link">Learn More →</Button>
              </div>
            </div>

            {/* Social Actions */}
            <div className="space-y-3 p-4 border rounded-lg">
              <h3 className="font-medium">Social Actions</h3>
              <div className="flex gap-2">
                <Button size="icon">👍</Button>
                <Button size="icon" variant="outline">💬</Button>
                <Button size="icon" variant="ghost">🔗</Button>
              </div>
            </div>

            {/* Toolbar */}
            <div className="space-y-3 p-4 border rounded-lg">
              <h3 className="font-medium">Toolbar</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline">B</Button>
                <Button size="sm" variant="outline">I</Button>
                <Button size="sm" variant="outline">U</Button>
                <Button size="sm" variant="outline">S</Button>
              </div>
            </div>

            {/* Call to Action */}
            <div className="space-y-3 p-4 border rounded-lg">
              <h3 className="font-medium">Call to Action</h3>
              <div className="flex flex-col gap-2">
                <Button size="lg">Get Started Free</Button>
                <Button size="lg" variant="outline">View Demo</Button>
              </div>
            </div>
          </div>
        </section>

        {/* Section 7: With Custom Tailwind Classes */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Custom Styling with Tailwind</h2>
          <div className="flex flex-wrap gap-4 items-center">
            <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
              Gradient
            </Button>
            <Button className="rounded-full px-6">
              Rounded Full
            </Button>
            <Button className="shadow-lg shadow-primary/50">
              Shadow Effect
            </Button>
            <Button className="uppercase tracking-wider">
              Uppercase
            </Button>
            <Button className="border-2 border-dashed">
              Dashed Border
            </Button>
          </div>
        </section>

        {/* Section 8: Width Variations */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Width Variations</h2>
          <div className="space-y-3">
            <Button className="w-full">Full Width Button</Button>
            <Button className="w-1/2">Half Width Button</Button>
            <Button className="w-1/3">One Third Width</Button>
            <Button className="min-w-[200px]">Minimum Width 200px</Button>
          </div>
        </section>

        {/* Section 9: Button Group Example */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground border-b pb-2">Button Groups</h2>
          <div className="flex flex-wrap gap-6">
            {/* Segmented Control */}
            <div className="inline-flex rounded-lg border overflow-hidden">
              <Button variant="ghost" className="rounded-none border-r">Day</Button>
              <Button variant="ghost" className="rounded-none border-r bg-muted">Week</Button>
              <Button variant="ghost" className="rounded-none">Month</Button>
            </div>

            {/* Pagination */}
            <div className="inline-flex rounded-lg border overflow-hidden">
              <Button variant="ghost" size="sm" className="rounded-none border-r">←</Button>
              <Button variant="ghost" size="sm" className="rounded-none border-r">1</Button>
              <Button variant="ghost" size="sm" className="rounded-none border-r bg-muted">2</Button>
              <Button variant="ghost" size="sm" className="rounded-none border-r">3</Button>
              <Button variant="ghost" size="sm" className="rounded-none">→</Button>
            </div>
          </div>
        </section>

        {/* Footer Note */}
        <div className="text-center pt-8 border-t">
          <p className="text-muted-foreground text-sm">
            All buttons are built with shadcn/ui • Radix UI primitives • Tailwind CSS
          </p>
        </div>

      </div>
    </div>
  )
}

export default Shad
