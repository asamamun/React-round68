# Shadcn/UI Installation and Setup Tutorial

## Overview
Shadcn/UI is a collection of re-usable components built using Radix UI and Tailwind CSS. It's not a component library, but rather a collection of components you can copy and paste into your apps.

## Prerequisites

Before installing shadcn/ui, ensure you have:
- ✅ React project with Vite
- ✅ Tailwind CSS v4 installed and configured
- ✅ Import alias (`@`) configured in your project
- ✅ Node.js and npm installed

## Step-by-Step Installation Guide

### Step 1: Add Your First Component

Run the following command to add a component (e.g., button):

```bash
npx shadcn@latest add button
```

### Step 2: Initial Setup Prompts

When you run the command for the first time, shadcn will ask you several questions:

#### 2.1 Create components.json
```
√ You need to create a components.json file to add components. Proceed? ... yes
```
This creates a configuration file that stores your shadcn preferences.

#### 2.2 Select Component Library
```
√ Select a component library » Radix
```
Choose **Radix** as the component library (recommended).

#### 2.3 Choose Preset
```
√ Which preset would you like to use? » Nova
```
Select **Nova** preset for modern styling.

### Step 3: Automatic Validation

Shadcn will automatically validate your setup:

```
√ Preflight checks.
√ Verifying framework. Found Vite.
√ Validating Tailwind CSS. Found v4.
√ Validating import alias.
```

It checks:
- Your framework (Vite)
- Tailwind CSS version (v4)
- Import alias configuration (`@`)

### Step 4: Configuration File Creation

```
√ Writing components.json.
```

This creates `components.json` in your project root with settings like:
```json
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "rsc": false,
  "tsx": false,
  "tailwind": {
    "config": "",
    "css": "src/index.css",
    "baseColor": "neutral",
    "cssVariables": true,
    "prefix": ""
  },
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  },
  "iconLibrary": "lucide"
}
```

### Step 5: Registry Check and Dependencies

```
√ Checking registry.
√ Installing dependencies.
```

Shadcn installs required dependencies like:
- `@radix-ui/react-slot`
- `class-variance-authority`
- `clsx`
- `tailwind-merge`
- `lucide-react`

### Step 6: Component Files Created

```
√ Created 2 files:
  - src\components\ui\button.jsx
  - src\lib\utils.js
```

**Files created:**
1. **`src/components/ui/button.jsx`** - The Button component
2. **`src/lib/utils.js`** - Utility functions (cn helper)

### Step 7: CSS Updates

```
√ Updating src\index.css
```

Your `index.css` is updated with shadcn-specific styles and imports:
- `@import "tw-animate-css"`
- `@import "shadcn/tailwind.css"`
- `@import "@fontsource-variable/geist"`
- CSS custom properties for theming
- Dark mode support
- Base layer styles

## Using Shadcn Components

### Import and Use Button Component

```jsx
import { Button } from "@/components/ui/button"

function App() {
  return (
    <div>
      <Button>Click Me</Button>
      <Button variant="secondary">Secondary</Button>
      <Button variant="destructive">Delete</Button>
      <Button variant="outline">Outline</Button>
      <Button variant="ghost">Ghost</Button>
      <Button variant="link">Link</Button>
    </div>
  )
}
```

### Adding More Components

To add more components, simply run:

```bash
npx shadcn@latest add card
npx shadcn@latest add input
npx shadcn@latest add dialog
npx shadcn@latest add dropdown-menu
```

Or add multiple at once:
```bash
npx shadcn@latest add card input dialog dropdown-menu
```

## Available Components

Popular shadcn/ui components include:
- **Form Elements**: button, input, textarea, select, checkbox, radio-group, switch
- **Layout**: card, accordion, tabs, separator, scroll-area
- **Overlays**: dialog, sheet, popover, tooltip, alert-dialog
- **Navigation**: dropdown-menu, menubar, navigation-menu, breadcrumb
- **Feedback**: alert, toast, progress, skeleton
- **Data Display**: table, avatar, badge, calendar
- **And many more...**

Visit [https://ui.shadcn.com/docs/components](https://ui.shadcn.com/docs/components) for the full list.

## Customization

### Modify components.json

You can customize your setup by editing `components.json`:

```json
{
  "style": "default",  // or "new-york"
  "tailwind": {
    "baseColor": "slate",  // Change color scheme
    "cssVariables": true
  }
}
```

### Customize Theme Colors

Edit your `src/index.css` to modify theme variables:

```css
:root {
  --primary: oklch(0.205 0 0);
  --primary-foreground: oklch(0.985 0 0);
  /* ... other variables */
}
```

### Override Component Styles

You can override component styles by modifying the component files directly in `src/components/ui/`.

## Project Structure

After installation, your project structure looks like:

```
src/
├── components/
│   └── ui/
│       ├── button.jsx
│       ├── card.jsx
│       └── ... (other components)
├── lib/
│   └── utils.js
├── index.css (updated with shadcn styles)
└── ...
```

## Key Features

### 1. **Copy and Paste**
Components are added to your codebase, not installed as a package. You have full control.

### 2. **Customizable**
Modify any component to fit your needs. It's your code!

### 3. **Type Safety**
Full TypeScript support (if using TypeScript).

### 4. **Accessible**
Built on Radix UI primitives, ensuring accessibility best practices.

### 5. **Dark Mode Ready**
Built-in dark mode support via CSS variables.

### 6. **Tailwind CSS Integration**
Seamlessly works with Tailwind CSS utility classes.

## Common Commands

```bash
# Add a single component
npx shadcn@latest add button

# Add multiple components
npx shadcn@latest add card input dialog

# Update existing components
npx shadcn@latest update

# Initialize shadcn (if needed)
npx shadcn@latest init
```

## Troubleshooting

### Issue: Import Alias Not Found
**Solution**: Ensure you have:
1. `jsconfig.json` or `tsconfig.json` with paths configured
2. `vite.config.js` with resolve.alias set up

### Issue: Tailwind CSS Not Detected
**Solution**: Verify:
1. Tailwind CSS is installed: `npm install -D tailwindcss postcss autoprefixer`
2. `tailwind.config.js` exists
3. `postcss.config.js` exists
4. `@tailwind` directives are in your CSS file

### Issue: Components Not Styling Correctly
**Solution**: Check:
1. `src/index.css` has shadcn imports
2. Tailwind CSS is properly configured
3. CSS file is imported in your main entry point

## Best Practices

1. **Only Add What You Need**: Don't add all components at once. Add them as needed.
2. **Customize After Adding**: Feel free to modify component files to match your design.
3. **Keep Updated**: Periodically run `npx shadcn@latest update` to get improvements.
4. **Use Variants**: Leverage component variants (e.g., button variants) for consistency.
5. **Combine with Tailwind**: Use Tailwind utility classes alongside shadcn components.

## Example: Complete Page

```jsx
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

function LoginPage() {
  return (
    <Card className="w-[350px] mx-auto mt-10">
      <CardHeader>
        <CardTitle>Login</CardTitle>
        <CardDescription>Enter your credentials to continue</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid w-full items-center gap-4">
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input id="email" placeholder="Enter your email" />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="Enter your password" />
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline">Cancel</Button>
        <Button>Login</Button>
      </CardFooter>
    </Card>
  )
}

export default LoginPage
```

## Resources

- **Official Documentation**: [https://ui.shadcn.com](https://ui.shadcn.com)
- **Component Gallery**: [https://ui.shadcn.com/docs/components](https://ui.shadcn.com/docs/components)
- **GitHub Repository**: [https://github.com/shadcn-ui/ui](https://github.com/shadcn-ui/ui)
- **Radix UI**: [https://www.radix-ui.com](https://www.radix-ui.com)

## Conclusion

Shadcn/ui provides a powerful, flexible way to build beautiful, accessible React components. By copying components into your codebase, you maintain full control while benefiting from professional, well-tested implementations.

Happy coding! 🚀
