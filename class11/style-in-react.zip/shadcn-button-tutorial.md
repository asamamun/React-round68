# Shadcn Button Component Tutorial for Students

## 📚 Learning Objectives

By the end of this tutorial, you will be able to:
- Install and configure shadcn/ui in a React + Vite project
- Add and use the Button component with different variants and sizes
- Customize buttons with Tailwind CSS
- Understand best practices for using shadcn components

---

## 🚀 Part 1: Prerequisites & Setup

### Step 1: Create a New React Project with Vite

Open your terminal and run:

```bash
npm create vite@latest my-shadcn-app -- --template react
cd my-shadcn-app
npm install
```

### Step 2: Install Tailwind CSS

```bash
npm install -D tailwindcss postcss autoprefixer @tailwindcss/postcss
```

### Step 3: Initialize Tailwind CSS

Create `tailwind.config.js`:

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

Create `postcss.config.js`:

```javascript
export default {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
}
```

### Step 4: Configure Import Alias

Create `jsconfig.json` in your project root:

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}
```

Update `vite.config.js`:

```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
```

### Step 5: Add Tailwind Directives to CSS

Update `src/index.css`:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

---

## 🎨 Part 2: Installing Shadcn/UI

### Step 1: Run the Shadcn Init Command

```bash
npx shadcn@latest init
```

You'll be prompted with several questions:

1. **Would you like to use TypeScript?** → No (or Yes if you prefer)
2. **Which style would you like to use?** → Default or New York
3. **Which color would you like to use as base color?** → Choose your preference
4. **Where is your global CSS file?** → `src/index.css`
5. **Do you want to use CSS variables for colors?** → Yes
6. **Are you using a custom tailwind prefix?** → No
7. **Where is your tailwind.config.js located?** → `tailwind.config.js`
8. **Configure the import alias for components:** → `@/components`
9. **Configure the import alias for utils:** → `@/lib/utils`

### Step 2: Install the Button Component

```bash
npx shadcn@latest add button
```

This command will:
- ✅ Create `src/components/ui/button.jsx`
- ✅ Create `src/lib/utils.js`
- ✅ Install required dependencies:
  - `class-variance-authority`
  - `clsx`
  - `tailwind-merge`
  - `@radix-ui/react-slot`
  - `lucide-react`

---

## 🎯 Part 3: Using the Button Component

### Basic Usage

Import and use the Button component in any React file:

```jsx
import { Button } from "@/components/ui/button"

function MyComponent() {
  return <Button>Click Me</Button>
}
```

### Button Variants

The Button component comes with 6 different variants:

#### 1. Default Button
```jsx
<Button>Default Button</Button>
```
**Use case**: Primary actions, form submissions, main CTAs

#### 2. Secondary Button
```jsx
<Button variant="secondary">Secondary</Button>
```
**Use case**: Less prominent actions, alternative options

#### 3. Destructive Button
```jsx
<Button variant="destructive">Delete</Button>
```
**Use case**: Delete actions, dangerous operations, warnings

#### 4. Outline Button
```jsx
<Button variant="outline">Outline</Button>
```
**Use case**: Secondary actions, cancel buttons, bordered style needed

#### 5. Ghost Button
```jsx
<Button variant="ghost">Ghost</Button>
```
**Use case**: Subtle actions, toolbar buttons, minimal UI

#### 6. Link Button
```jsx
<Button variant="link">Link Style</Button>
```
**Use case**: Navigation links that look like buttons, inline actions

---

## 📏 Part 4: Button Sizes

The Button component supports 4 sizes:

### Extra Small
```jsx
<Button size="xs">XS</Button>
```

### Small
```jsx
<Button size="sm">Small</Button>
```

### Default (Medium)
```jsx
<Button size="default">Default</Button>
// or simply
<Button>Default</Button>
```

### Large
```jsx
<Button size="lg">Large</Button>
```

### Icon Sizes
For icon-only buttons:
```jsx
<Button size="icon-xs">📌</Button>
<Button size="icon-sm">⭐</Button>
<Button size="icon">❤️</Button>
<Button size="icon-lg">🚀</Button>
```

---

## 🔧 Part 5: Combining Variants and Sizes

You can mix any variant with any size:

```jsx
// Large destructive button
<Button variant="destructive" size="lg">Delete Account</Button>

// Small outline button
<Button variant="outline" size="sm">Cancel</Button>

// Extra small ghost button
<Button variant="ghost" size="xs">Close</Button>

// Large secondary button
<Button variant="secondary" size="lg">Learn More</Button>
```

---

## 🎨 Part 6: Custom Styling with Tailwind CSS

Add custom Tailwind classes to customize button appearance:

### Gradient Background
```jsx
<Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
  Gradient Button
</Button>
```

### Rounded Corners
```jsx
<Button className="rounded-full">Rounded Button</Button>
```

### Shadow Effect
```jsx
<Button className="shadow-lg shadow-blue-500/50">Shadow Button</Button>
```

### Custom Width
```jsx
<Button className="w-full">Full Width Button</Button>
<Button className="w-1/2">Half Width</Button>
<Button className="min-w-[200px]">Minimum Width</Button>
```

### Text Styling
```jsx
<Button className="uppercase tracking-wider font-bold">Styled Text</Button>
```

---

## 💡 Part 7: Practical Examples

### Example 1: Form Actions
```jsx
import { Button } from "@/components/ui/button"

function ContactForm() {
  return (
    <form>
      {/* Form fields here */}
      <div className="flex gap-2 justify-end">
        <Button variant="outline" type="button">Cancel</Button>
        <Button type="submit">Submit</Button>
      </div>
    </form>
  )
}
```

### Example 2: Delete Confirmation
```jsx
function DeleteConfirmation() {
  return (
    <div className="flex gap-2">
      <Button variant="outline">Keep Item</Button>
      <Button variant="destructive">Delete Forever</Button>
    </div>
  )
}
```

### Example 3: Card Actions
```jsx
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

function ProductCard() {
  return (
    <Card>
      <CardContent>
        <h3>Product Name</h3>
        <p>$99.99</p>
      </CardContent>
      <CardFooter className="flex gap-2">
        <Button variant="outline" size="sm">Details</Button>
        <Button size="sm">Add to Cart</Button>
      </CardFooter>
    </Card>
  )
}
```

### Example 4: Navigation Buttons
```jsx
function PageNavigation() {
  return (
    <div className="flex justify-between">
      <Button variant="ghost">← Previous</Button>
      <Button>Next →</Button>
    </div>
  )
}
```

### Example 5: Toolbar
```jsx
function TextEditorToolbar() {
  return (
    <div className="flex gap-1 p-2 border rounded">
      <Button size="sm" variant="ghost">B</Button>
      <Button size="sm" variant="ghost">I</Button>
      <Button size="sm" variant="ghost">U</Button>
      <Button size="sm" variant="ghost">S</Button>
    </div>
  )
}
```

---

## ⚙️ Part 8: Button States

### Disabled State
```jsx
<Button disabled>Cannot Click</Button>
```

### Loading State (Custom Implementation)
```jsx
<Button disabled>
  <span className="animate-spin mr-2">⟳</span>
  Loading...
</Button>
```

---

## 🎓 Part 9: Student Exercises

### Exercise 1: Basic Button Gallery
Create a page that displays all button variants and sizes in a grid layout.

**Requirements:**
- Show all 6 variants
- Show all 4 sizes
- Label each button clearly

### Exercise 2: Login Form
Build a login form with:
- Email input field
- Password input field
- "Login" button (primary)
- "Cancel" button (outline)
- "Forgot Password?" link button

### Exercise 3: Product Listing
Create a product card component with:
- Product image placeholder
- Product name and price
- "Add to Cart" button (primary)
- "View Details" button (outline)
- "Remove" button (destructive, small)

### Exercise 4: Dashboard Header
Build a dashboard header with:
- App title
- User profile button (ghost)
- Notifications button with icon (ghost)
- Settings button (outline)

### Exercise 5: Custom Styled Buttons
Create 5 uniquely styled buttons using Tailwind CSS:
1. Gradient background button
2. Button with shadow effect
3. Fully rounded (pill) button
4. Button with custom border
5. Button with hover animation

---

## 📝 Part 10: Best Practices

### ✅ DO:
1. **Use appropriate variants**: Match button variant to action importance
   - Primary actions → `default`
   - Secondary actions → `outline` or `secondary`
   - Destructive actions → `destructive`

2. **Maintain consistency**: Use consistent sizes within similar contexts

3. **Provide clear labels**: Button text should clearly indicate the action

4. **Use disabled state**: Disable buttons when actions aren't available

5. **Consider accessibility**: Ensure sufficient color contrast

### ❌ DON'T:
1. **Don't overuse destructive variant**: Reserve for truly dangerous actions

2. **Don't mix too many sizes**: Keep button sizes consistent in the same context

3. **Don't use link variant for important actions**: It's too subtle

4. **Don't forget hover states**: Test how buttons look on hover

5. **Don't ignore mobile**: Ensure buttons are touch-friendly (min 44px height)

---

## 🔍 Part 11: Troubleshooting

### Issue: "Module not found: Can't resolve '@/components/ui/button'"
**Solution**: 
- Ensure `jsconfig.json` exists with correct paths
- Ensure `vite.config.js` has the alias configured
- Restart your dev server

### Issue: "Button has no styling"
**Solution**:
- Verify Tailwind CSS is properly installed
- Check that `@tailwind` directives are in `index.css`
- Ensure `postcss.config.js` uses `'@tailwindcss/postcss'`

### Issue: "Dependencies not installed"
**Solution**:
Run: `npm install class-variance-authority clsx tailwind-merge @radix-ui/react-slot lucide-react`

### Issue: "Button looks different than expected"
**Solution**:
- Check if you're using the correct variant and size props
- Verify no conflicting CSS classes
- Ensure shadcn theme variables are loaded

---

## 📚 Part 12: Additional Resources

### Official Documentation
- **Shadcn/UI**: https://ui.shadcn.com
- **Button Component**: https://ui.shadcn.com/docs/components/button
- **Tailwind CSS**: https://tailwindcss.com/docs

### Learn More Components
After mastering buttons, explore other shadcn components:
```bash
npx shadcn@latest add card
npx shadcn@latest add input
npx shadcn@latest add dialog
npx shadcn@latest add dropdown-menu
```

### Useful Commands
```bash
# Add a new component
npx shadcn@latest add [component-name]

# Update existing components
npx shadcn@latest update

# View all available components
# Visit: https://ui.shadcn.com/docs/components
```

---

## 🎉 Conclusion

Congratulations! You've learned how to:
- ✅ Set up shadcn/ui in a React + Vite project
- ✅ Install and configure the Button component
- ✅ Use different button variants and sizes
- ✅ Customize buttons with Tailwind CSS
- ✅ Apply best practices for button usage
- ✅ Build practical UI examples

Now it's time to practice! Complete the exercises above and start building amazing user interfaces with shadcn/ui buttons.

**Happy Coding! 🚀**

---

## 📖 Quick Reference Card

### Button Variants
| Variant | Prop | Use Case |
|---------|------|----------|
| Default | `variant="default"` | Primary actions |
| Secondary | `variant="secondary"` | Alternative actions |
| Destructive | `variant="destructive"` | Delete/danger actions |
| Outline | `variant="outline"` | Secondary/border style |
| Ghost | `variant="ghost"` | Subtle/minimal actions |
| Link | `variant="link"` | Navigation links |

### Button Sizes
| Size | Prop | Height |
|------|------|--------|
| Extra Small | `size="xs"` | 24px |
| Small | `size="sm"` | 28px |
| Default | `size="default"` | 32px |
| Large | `size="lg"` | 36px |

### Common Patterns
```jsx
// Form submission
<Button type="submit">Submit</Button>

// Cancel action
<Button variant="outline" type="button">Cancel</Button>

// Delete action
<Button variant="destructive">Delete</Button>

// Full width CTA
<Button className="w-full">Get Started</Button>

// Icon button
<Button size="icon">🔔</Button>
```
