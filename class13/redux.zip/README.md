# Redux Shopping Cart - Learning Project

A comprehensive React application built with Redux Toolkit to help students understand state management concepts through a real-world shopping cart example.

## 🎯 Learning Objectives

By completing this project, students will understand:
- Redux Store configuration
- Actions and Reducers
- Async operations with Redux Thunk
- React-Redux hooks (useSelector, useDispatch)
- State normalization and immutability
- Integration with React Router

## 🚀 Getting Started

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn
- Backend API running at `http://localhost/round68/php/classes/class34Project/Multivendor-E-commerce-in-PHP-MYSQL/apis/`

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open your browser and navigate to:
```
http://localhost:5173
```

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   └── Navbar.jsx      # Navigation with cart badge
├── pages/              # Route components
│   ├── Home.jsx        # Landing page
│   ├── Products.jsx    # Product listing
│   ├── ProductDetails.jsx  # Single product view
│   └── Cart.jsx        # Shopping cart
├── services/           # API integration
│   └── api.js          # Axios API calls
├── store/              # Redux store
│   ├── index.js        # Store configuration
│   └── slices/         # Redux slices
│       ├── productsSlice.js  # Products state
│       └── cartSlice.js      # Cart state
├── App.jsx             # Main app with routes
└── main.jsx            # Entry point with Provider
```

## 📚 Key Features

### 1. Product Management
- Fetch products from API
- Display product grid
- View product details
- Loading and error states

### 2. Shopping Cart
- Add products to cart
- Update quantities (+/-)
- Remove items
- Calculate totals automatically
- Persistent cart badge in navbar

### 3. Navigation
- React Router integration
- Dynamic routing for products
- Protected navigation with cart count

## 🔧 Redux Concepts Covered

### Store
Central state container holding all application data.

**Location**: `src/store/index.js`

### Slices
Modular state management combining actions and reducers.

**Products Slice**: Manages product data and async fetching
**Cart Slice**: Manages cart items and calculations

### Actions
- `loadProducts(limit)` - Fetch products from API
- `loadProductById(id)` - Fetch single product
- `addToCart(product)` - Add item to cart
- `removeFromCart(id)` - Remove item from cart
- `updateQuantity({id, quantity})` - Update item quantity
- `clearCart()` - Clear entire cart

### Selectors
Extract data from Redux store using `useSelector` hook.

### Dispatch
Send actions to store using `useDispatch` hook.

## 📖 Documentation

Detailed explanation of Redux concepts is available in [redux.md](./redux.md). This includes:
- Core Redux concepts
- Step-by-step implementation guide
- Code examples
- Best practices
- Common patterns
- Exercises for practice

## 🎨 Styling

The application uses inline styles for simplicity and clarity. In production, consider using:
- CSS Modules
- Styled Components
- Tailwind CSS
- Sass/SCSS

## 🔍 Debugging

### Redux DevTools
Install the [Redux DevTools Extension](https://github.com/reduxjs/redux-devtools) for Chrome/Firefox to:
- Track all actions
- Inspect state changes
- Time-travel debugging
- Action replay

### Console Logging
Actions and state changes are logged automatically when using Redux DevTools.

## 🧪 Testing Your Understanding

Try these exercises:

1. **Add Wishlist Feature**
   - Create a new slice for wishlist
   - Add/remove products from wishlist
   - Display wishlist page

2. **Add User Authentication**
   - Create auth slice
   - Login/logout functionality
   - Protect routes based on auth state

3. **Persist Cart to LocalStorage**
   - Save cart on every change
   - Load cart on app start
   - Handle hydration

4. **Add Product Search**
   - Filter products by name
   - Debounced search input
   - Display search results

5. **Add Discount Codes**
   - Apply discount to cart
   - Validate coupon codes
   - Update total price

## 🛠️ Technologies Used

- **React 19** - UI library
- **Redux Toolkit** - State management
- **React Router DOM** - Client-side routing
- **Axios** - HTTP client
- **Vite** - Build tool and dev server

## 📝 API Endpoints

The application expects these endpoints:

```
GET /products.php?limit=50    - Fetch all products
GET /products.php?id=129      - Fetch single product
```

Update the API base URL in `src/services/api.js` if needed.

## 💡 Tips for Students

1. **Start Simple**: Understand the counter example first
2. **Follow the Flow**: Trace action → reducer → state update
3. **Use DevTools**: Visualize state changes
4. **Read the Docs**: Check redux.md for detailed explanations
5. **Experiment**: Modify code and observe changes
6. **Ask Questions**: Don't hesitate to clarify doubts

## 🤝 Contributing

This is a learning project. Feel free to:
- Add new features
- Improve documentation
- Fix bugs
- Share feedback

## 📄 License

This project is for educational purposes.

## 🎓 Additional Resources

- [Redux Official Documentation](https://redux.js.org/)
- [Redux Toolkit Documentation](https://redux-toolkit.js.org/)
- [React-Redux Documentation](https://react-redux.js.org/)
- [React Router Documentation](https://reactrouter.com/)

---

**Happy Learning! 🚀**

For detailed Redux explanations, see [redux.md](./redux.md)
