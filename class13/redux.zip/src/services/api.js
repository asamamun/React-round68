import axios from 'axios';

const API_BASE_URL = 'http://localhost/round68/php/classes/class34Project/Multivendor-E-commerce-in-PHP-MYSQL/apis';
const ASSET_BASE_URL = 'http://localhost/round68/php/classes/class34Project/Multivendor-E-commerce-in-PHP-MYSQL';

// Helper function to construct full image URL
export const getImageUrl = (imagePath) => {
  if (!imagePath) {
    // Return a simple SVG data URI as fallback instead of external placeholder
    return "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f0f0'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-family='Arial' font-size='16' fill='%23999'%3ENo Image%3C/text%3E%3C/svg%3E";
  }
  
  // If already a full URL, return as is
  if (imagePath.startsWith('http')) return imagePath;
  
  // If path starts with /, prepend asset base URL
  if (imagePath.startsWith('/')) return `${ASSET_BASE_URL}${imagePath}`;
  
  // Otherwise, assume it's a relative path
  return `${ASSET_BASE_URL}/${imagePath}`;
};

// Fetch all products with optional limit
export const fetchProducts = async (limit = 50) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products.php`, {
      params: { limit }
    });
    
    console.log('=== API Response Structure ===');
    console.log('Full response:', response.data);
    
    // Extract products from the nested structure: response.data.data.products
    let products = [];
    
    if (response.data && response.data.success) {
      if (response.data.data && response.data.data.products) {
        products = response.data.data.products;
        console.log(`✅ Found ${products.length} products in data.products`);
      } else if (response.data.data && Array.isArray(response.data.data)) {
        products = response.data.data;
        console.log(`✅ Found ${products.length} products in data array`);
      } else if (Array.isArray(response.data)) {
        products = response.data;
        console.log(`✅ Found ${products.length} products in root array`);
      }
    }
    
    if (products.length === 0) {
      console.warn('⚠️ No products found in API response');
      console.log('Response structure:', Object.keys(response.data));
    }
    
    // Process products to add full image URLs and ensure valid data
    const processedProducts = products.map((product, index) => {
      // Map API fields to our expected fields
      return {
        id: product.id,
        name: product.name,
        slug: product.slug,
        price: parseFloat(product.price) || 0,
        compare_price: parseFloat(product.compare_price) || 0,
        stock_quantity: product.stock_quantity,
        short_description: product.short_description,
        featured: product.featured,
        rating: parseFloat(product.rating) || 0,
        review_count: product.review_count,
        category_name: product.category_name,
        vendor_name: product.vendor_name,
        // Map primary_image to image field and construct full URL
        image: getImageUrl(product.primary_image),
        // Keep original data for reference
        _original: product
      };
    });
    
    console.log('=== Processed Products Sample ===');
    console.log('First product:', processedProducts[0]);
    console.log('Total processed:', processedProducts.length);
    
    return processedProducts;
  } catch (error) {
    console.error('❌ Error fetching products:', error);
    throw error;
  }
};

// Fetch single product by ID
export const fetchProductById = async (id) => {
  try {
    console.log('=== Fetching Single Product ===');
    console.log('Requested ID:', id);
    
    const response = await axios.get(`${API_BASE_URL}/products.php`, {
      params: { id }
    });
    
    console.log('=== Single Product API Response ===');
    console.log('Full response:', JSON.stringify(response.data, null, 2));
    console.log('Response type:', typeof response.data);
    console.log('Is array?', Array.isArray(response.data));
    
    // Extract product from nested structure
    let productData = null;
    
    if (response.data && response.data.success) {
      if (response.data.data) {
        if (response.data.data.product) {
          // Single product response: { data: { product: {...} } }
          productData = response.data.data.product;
        } else if (Array.isArray(response.data.data)) {
          productData = response.data.data.find(p => p.id == id || p.product_id == id);
        } else if (response.data.data.products && Array.isArray(response.data.data.products)) {
          productData = response.data.data.products.find(p => p.id == id || p.product_id == id);
        } else {
          productData = response.data.data;
        }
      }
    } else if (Array.isArray(response.data)) {
      // Direct array response
      console.log('✅ Response is direct array');
      productData = response.data.find(p => p.id == id || p.product_id == id);
      if (!productData && response.data.length > 0) {
        productData = response.data[0];
      }
    } else if (response.data && typeof response.data === 'object') {
      // Direct object response
      console.log('✅ Response is direct object');
      productData = response.data;
    }
    
    if (!productData) {
      throw new Error('Product not found');
    }
    
    const mappedProduct = {
      id: productData.id,
      name: productData.name,
      slug: productData.slug,
      price: parseFloat(productData.price) || 0,
      compare_price: parseFloat(productData.compare_price) || 0,
      stock_quantity: productData.stock_quantity,
      short_description: productData.short_description,
      featured: productData.featured,
      rating: parseFloat(productData.rating) || 0,
      review_count: productData.review_count,
      category_name: productData.category_name,
      vendor_name: productData.vendor_name,
      description: productData.description || productData.short_description,
      // Map primary_image to image field and construct full URL
      image: getImageUrl(productData.primary_image || productData.image)
    };
    
    return mappedProduct;
  } catch (error) {
    console.error(`❌ Error fetching product ${id}:`, error);
    throw error;
  }
};
