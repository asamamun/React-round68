import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { loadProducts } from '../store/slices/productsSlice';
import { addToCart } from '../store/slices/cartSlice';

const Products = () => {
  const dispatch = useDispatch();
  const { items: products, loading, error } = useSelector((state) => state.products);

  useEffect(() => {
    // Only fetch if products array is empty to prevent infinite loops
    if (products.length === 0) {
      dispatch(loadProducts(50));
    }
  }, [dispatch, products.length]);

  const handleAddToCart = (product) => {
    // Dispatch action to add product to cart
    dispatch(addToCart(product));
  };

  if (loading) {
    return (
      <div style={styles.loading}>
        <p>Loading products...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.error}>
        <p>Error: {error}</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>All Products</h1>
      <p style={styles.subtitle}>{products.length} products available</p>
      
      <div style={styles.grid}>
        {products.map((product, index) => {
          // Ensure price is a valid number
          const price = parseFloat(product.price) || 0;
          const productName = product.name || product.product_name || 'Unknown Product';
          const productId = product.id || product.product_id || `product-${index}`;
          
          return (
            <div key={productId} style={styles.card}>
              <Link to={`/product/${productId}`} style={styles.link}>
                <div style={styles.imageContainer}>
                  <img 
                    src={product.image} 
                    alt={productName}
                    style={styles.image}
                  />
                </div>
                <div style={styles.content}>
                  <h3 style={styles.productName}>{productName}</h3>
                  <p style={styles.price}>${price.toFixed(2)}</p>
                  <p style={styles.description}>
                    {product.description ? product.description.substring(0, 100) + '...' : 'No description available'}
                  </p>
                </div>
              </Link>
              <button 
                onClick={() => handleAddToCart({...product, id: productId, name: productName, price})}
                style={styles.addButton}
              >
                Add to Cart
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '100%',
    margin: '0 auto',
    padding: '2rem 1rem',
  },
  title: {
    fontSize: '2.5rem',
    marginBottom: '0.5rem',
    color: '#2c3e50',
  },
  subtitle: {
    fontSize: '1.1rem',
    color: '#7f8c8d',
    marginBottom: '2rem',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
    gap: '1.5rem',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
    overflow: 'hidden',
    transition: 'transform 0.2s, box-shadow 0.2s',
    display: 'flex',
    flexDirection: 'column',
  },
  link: {
    textDecoration: 'none',
    color: 'inherit',
    flex: 1,
  },
  imageContainer: {
    width: '100%',
    height: '250px',
    overflow: 'hidden',
    backgroundColor: '#f5f5f5',
  },
  image: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  content: {
    padding: '1.5rem',
    flex: 1,
  },
  productName: {
    fontSize: '1.25rem',
    marginBottom: '0.5rem',
    color: '#2c3e50',
  },
  price: {
    fontSize: '1.5rem',
    fontWeight: 'bold',
    color: '#27ae60',
    marginBottom: '0.5rem',
  },
  description: {
    fontSize: '0.9rem',
    color: '#7f8c8d',
    lineHeight: '1.5',
  },
  addButton: {
    width: '100%',
    padding: '1rem',
    backgroundColor: '#3498db',
    color: 'white',
    border: 'none',
    fontSize: '1rem',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  loading: {
    textAlign: 'center',
    padding: '4rem',
    fontSize: '1.25rem',
    color: '#7f8c8d',
  },
  error: {
    textAlign: 'center',
    padding: '4rem',
    fontSize: '1.25rem',
    color: '#e74c3c',
  },
};

export default Products;
