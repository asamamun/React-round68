import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { removeFromCart, updateQuantity, clearCart } from '../store/slices/cartSlice';

const Cart = () => {
  const dispatch = useDispatch();
  const { items, totalItems, totalPrice } = useSelector((state) => state.cart);

  const handleRemoveItem = (productId) => {
    dispatch(removeFromCart(productId));
  };

  const handleUpdateQuantity = (productId, newQuantity) => {
    dispatch(updateQuantity({ id: productId, quantity: newQuantity }));
  };

  const handleClearCart = () => {
    if (window.confirm('Are you sure you want to clear your cart?')) {
      dispatch(clearCart());
    }
  };

  if (items.length === 0) {
    return (
      <div style={styles.emptyCart}>
        <h2>Your cart is empty</h2>
        <p>Add some products to get started!</p>
        <Link to="/products" style={styles.shopButton}>
          Browse Products
        </Link>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Shopping Cart</h1>
      <p style={styles.subtitle}>{totalItems} item{totalItems !== 1 ? 's' : ''} in cart</p>

      <div style={styles.cartContent}>
        <div style={styles.itemsList}>
          {items.map((item, index) => (
            <div key={item.id || `cart-item-${index}`} style={styles.cartItem}>
              <Link to={`/product/${item.id}`} style={styles.itemLink}>
                <img 
                  src={item.image} 
                  alt={item.name}
                  style={styles.itemImage}
                />
              </Link>
              
              <div style={styles.itemDetails}>
                <Link to={`/product/${item.id}`} style={styles.itemNameLink}>
                  <h3 style={styles.itemName}>{item.name}</h3>
                </Link>
                <p style={styles.itemPrice}>${parseFloat(item.price).toFixed(2)}</p>
              </div>

              <div style={styles.quantityControls}>
                <button 
                  onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                  style={styles.quantityButton}
                  disabled={item.quantity <= 1}
                >
                  -
                </button>
                <span style={styles.quantity}>{item.quantity}</span>
                <button 
                  onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                  style={styles.quantityButton}
                >
                  +
                </button>
              </div>

              <div style={styles.itemTotal}>
                ${(item.price * item.quantity).toFixed(2)}
              </div>

              <button 
                onClick={() => handleRemoveItem(item.id)}
                style={styles.removeButton}
              >
                Remove
              </button>
            </div>
          ))}
        </div>

        <div style={styles.summary}>
          <h2 style={styles.summaryTitle}>Order Summary</h2>
          
          <div style={styles.summaryRow}>
            <span>Subtotal ({totalItems} items)</span>
            <span>${totalPrice.toFixed(2)}</span>
          </div>
          
          <div style={styles.summaryRow}>
            <span>Shipping</span>
            <span>Free</span>
          </div>
          
          <div style={styles.divider}></div>
          
          <div style={styles.totalRow}>
            <span>Total</span>
            <span style={styles.totalAmount}>${totalPrice.toFixed(2)}</span>
          </div>

          <button style={styles.checkoutButton}>
            Proceed to Checkout
          </button>

          <button onClick={handleClearCart} style={styles.clearButton}>
            Clear Cart
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '2rem',
  },
  title: {
    fontSize: '2.5rem',
    marginBottom: '0.5rem',
    color: '#2c3e50',
  },
  subtitle: {
    fontSize: '1.1rem',
    color: '#7f8c8d',
    marginBottom: '2rem',
  },
  cartContent: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: '2rem',
  },
  itemsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  cartItem: {
    display: 'grid',
    gridTemplateColumns: '100px 1fr auto auto auto',
    gap: '1.5rem',
    alignItems: 'center',
    padding: '1.5rem',
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  },
  itemLink: {
    textDecoration: 'none',
  },
  itemImage: {
    width: '100px',
    height: '100px',
    objectFit: 'cover',
    borderRadius: '8px',
  },
  itemDetails: {
    flex: 1,
  },
  itemNameLink: {
    textDecoration: 'none',
    color: 'inherit',
  },
  itemName: {
    fontSize: '1.25rem',
    marginBottom: '0.5rem',
    color: '#2c3e50',
  },
  itemPrice: {
    fontSize: '1rem',
    color: '#27ae60',
    fontWeight: 'bold',
  },
  quantityControls: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
  },
  quantityButton: {
    width: '32px',
    height: '32px',
    border: '1px solid #ddd',
    backgroundColor: 'white',
    borderRadius: '4px',
    fontSize: '1.25rem',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantity: {
    fontSize: '1.1rem',
    fontWeight: 'bold',
    minWidth: '30px',
    textAlign: 'center',
  },
  itemTotal: {
    fontSize: '1.25rem',
    fontWeight: 'bold',
    color: '#2c3e50',
    minWidth: '80px',
    textAlign: 'right',
  },
  removeButton: {
    padding: '0.5rem 1rem',
    backgroundColor: '#e74c3c',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.9rem',
  },
  summary: {
    padding: '2rem',
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    height: 'fit-content',
    position: 'sticky',
    top: '2rem',
  },
  summaryTitle: {
    fontSize: '1.5rem',
    marginBottom: '1.5rem',
    color: '#2c3e50',
  },
  summaryRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '1rem',
    fontSize: '1rem',
    color: '#7f8c8d',
  },
  divider: {
    height: '1px',
    backgroundColor: '#ecf0f1',
    margin: '1.5rem 0',
  },
  totalRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '2rem',
    fontSize: '1.5rem',
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  totalAmount: {
    color: '#27ae60',
  },
  checkoutButton: {
    width: '100%',
    padding: '1rem',
    backgroundColor: '#27ae60',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '1.1rem',
    fontWeight: 'bold',
    cursor: 'pointer',
    marginBottom: '1rem',
  },
  clearButton: {
    width: '100%',
    padding: '1rem',
    backgroundColor: 'transparent',
    color: '#e74c3c',
    border: '2px solid #e74c3c',
    borderRadius: '8px',
    fontSize: '1rem',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  emptyCart: {
    textAlign: 'center',
    padding: '4rem 2rem',
  },
  shopButton: {
    display: 'inline-block',
    marginTop: '2rem',
    padding: '1rem 2rem',
    backgroundColor: '#3498db',
    color: 'white',
    textDecoration: 'none',
    borderRadius: '8px',
    fontSize: '1.1rem',
    fontWeight: 'bold',
  },
};

export default Cart;
