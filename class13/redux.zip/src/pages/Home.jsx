import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div style={styles.container}>
      <div style={styles.hero}>
        <h1 style={styles.title}>Welcome to Redux Shop</h1>
        <p style={styles.subtitle}>
          Learn Redux by building a real-world shopping cart application
        </p>
        <div style={styles.buttons}>
          <Link to="/products" style={styles.primaryButton}>
            Browse Products
          </Link>
          <Link to="/cart" style={styles.secondaryButton}>
            View Cart
          </Link>
        </div>
      </div>

      <div style={styles.features}>
        <h2 style={styles.featuresTitle}>What You'll Learn</h2>
        <div style={styles.featureGrid}>
          <div style={styles.featureCard}>
            <h3>📦 Redux Store</h3>
            <p>Central state management for your entire application</p>
          </div>
          <div style={styles.featureCard}>
            <h3>🔄 Actions & Reducers</h3>
            <p>Predictable state updates with pure functions</p>
          </div>
          <div style={styles.featureCard}>
            <h3>⚡ Async Operations</h3>
            <p>Handle API calls with Redux Thunk</p>
          </div>
          <div style={styles.featureCard}>
            <h3>🎣 React Hooks</h3>
            <p>Use useSelector and useDispatch for clean integration</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: 'calc(100vh - 64px)',
  },
  hero: {
    textAlign: 'center',
    padding: '4rem 2rem',
    backgroundColor: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
  },
  title: {
    fontSize: '3rem',
    marginBottom: '1rem',
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: '1.25rem',
    marginBottom: '2rem',
    opacity: 0.9,
  },
  buttons: {
    display: 'flex',
    gap: '1rem',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  primaryButton: {
    padding: '1rem 2rem',
    backgroundColor: 'white',
    color: '#667eea',
    textDecoration: 'none',
    borderRadius: '8px',
    fontWeight: 'bold',
    fontSize: '1.1rem',
    transition: 'transform 0.2s',
  },
  secondaryButton: {
    padding: '1rem 2rem',
    backgroundColor: 'transparent',
    color: 'white',
    textDecoration: 'none',
    borderRadius: '8px',
    fontWeight: 'bold',
    fontSize: '1.1rem',
    border: '2px solid white',
    transition: 'transform 0.2s',
  },
  features: {
    padding: '4rem 2rem',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  featuresTitle: {
    textAlign: 'center',
    fontSize: '2rem',
    marginBottom: '3rem',
    color: '#2c3e50',
  },
  featureGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '2rem',
  },
  featureCard: {
    padding: '2rem',
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
    textAlign: 'center',
    transition: 'transform 0.2s',
  },
};

export default Home;
