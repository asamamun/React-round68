import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { loadProductById, clearSelectedProduct } from '../store/slices/productsSlice';
import { addToCart } from '../store/slices/cartSlice';

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const { items, selectedProduct, loading, error } = useSelector((state) => state.products);
  
  // Try to find product from already-loaded items first
  const product = selectedProduct || items.find(p => p.id == id);

  useEffect(() => {
    // Only fetch if product not already in store
    if (!items.find(p => p.id == id)) {
      dispatch(loadProductById(id));
    }

    return () => {
      dispatch(clearSelectedProduct());
    };
  }, [dispatch, id]);


  const handleAddToCart = () => {
    if (product) {
      dispatch(addToCart(product));
    }
  };

  const handleBack = () => {
    navigate('/products');
  };

  if (loading) {
    return (
      <div style={styles.loading}>
        <p>Loading product details...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.error}>
        <p>Error: {error}</p>
        <button onClick={handleBack} style={styles.backButton}>
          Back to Products
        </button>
      </div>
    );
  }

  if (!product) {
    return (
      <div style={styles.notFound}>
        <p>Product not found</p>
        <button onClick={handleBack} style={styles.backButton}>
          Back to Products
        </button>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <button onClick={handleBack} style={styles.backButton}>
        ← Back to Products
      </button>

      <div style={styles.productCard}>
        <div style={styles.imageSection}>
          <img 
            src={product.image} 
            alt={product.name}
            style={styles.image}
            onError={(e) => {
              console.error('Image failed to load:', product.image);
              console.log('Product data:', product);
              e.target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='500' height='500' viewBox='0 0 500 500'%3E%3Crect width='500' height='500' fill='%23f0f0f0'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-family='Arial' font-size='20' fill='%23999'%3ENo Image Available%3C/text%3E%3C/svg%3E";
            }}
          />
        </div>

        <div style={styles.detailsSection}>
          <h1 style={styles.title}>{product.name}</h1>
          <p style={styles.price}>${parseFloat(product.price).toFixed(2)}</p>
          
          <div style={styles.description}>
            <h3>Description</h3>
            <p>{product.description || 'No description available'}</p>
          </div>

          {product.category_name && (
            <div style={styles.category}>
              <strong>Category:</strong> {product.category_name}
            </div>
          )}

          {product.stock_quantity !== undefined && (
            <div style={styles.stock}>
              <strong>Stock:</strong> {product.stock_quantity} units available
            </div>
          )}

          <button onClick={handleAddToCart} style={styles.addButton}>
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '2rem',
  },
  backButton: {
    padding: '0.75rem 1.5rem',
    backgroundColor: '#34495e',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    cursor: 'pointer',
    marginBottom: '2rem',
    transition: 'background-color 0.2s',
  },
  productCard: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '3rem',
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
    overflow: 'hidden',
  },
  imageSection: {
    width: '100%',
    height: '500px',
    backgroundColor: '#f5f5f5',
  },
  image: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  detailsSection: {
    padding: '2rem',
    display: 'flex',
    flexDirection: 'column',
  },
  title: {
    fontSize: '2.5rem',
    marginBottom: '1rem',
    color: '#2c3e50',
  },
  price: {
    fontSize: '2rem',
    fontWeight: 'bold',
    color: '#27ae60',
    marginBottom: '2rem',
  },
  description: {
    marginBottom: '2rem',
  },
  category: {
    padding: '1rem',
    backgroundColor: '#ecf0f1',
    borderRadius: '6px',
    marginBottom: '1rem',
  },
  stock: {
    padding: '1rem',
    backgroundColor: '#e8f5e9',
    borderRadius: '6px',
    marginBottom: '2rem',
  },
  addButton: {
    padding: '1.25rem',
    backgroundColor: '#3498db',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '1.25rem',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    marginTop: 'auto',
  },
  loading: {
    textAlign: 'center',
    padding: '4rem',
    fontSize: '1.25rem',
    color: '#7f8c8d',
  },
  error: {
    textAlign: 'center',
    padding: '4rem',
    fontSize: '1.25rem',
    color: '#e74c3c',
  },
  notFound: {
    textAlign: 'center',
    padding: '4rem',
    fontSize: '1.25rem',
    color: '#7f8c8d',
  },
};

export default ProductDetails;
