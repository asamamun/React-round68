import React, { useReducer, useState } from 'react';

const initialState = { 
    round: 68, 
    batch:"WDPF",
    students:[], 
    subjects:["HTML","CSS","JS", "PHP", "MYSQL"] 
  };
  //reducer
  const reducer = (state, action) => {
    switch (action.type) {
      case "ADD_STUDENT":
        return { ...state, students: [...state.students, action.payload] };
      case "REMOVE_STUDENT":
        return { ...state, students: state.students.filter((student) => student !== action.payload) };
      case "ADD_SUBJECT":
        return { ...state, subjects: [...state.subjects, action.payload] };
      case "REMOVE_SUBJECT":
        return { ...state, subjects: state.subjects.filter((subject) => subject !== action.payload) };
      case "CHANGE_ROUND":  
        return { ...state, round: action.payload };
      case "CHANGE_BATCH":  
        return { ...state, batch: action.payload };
        default:
        return state;
    }
  };
const App = () => {
  const [newStudent, setNewStudent] = useState("");
  const [newSubject, setNewSubject] = useState("");
  const [newRound, setNewRound] = useState("");
  const [newBatch, setNewBatch] = useState("");
  
  const [state, dispatch] = useReducer(reducer, initialState);
  const addStudent = (student) => {
    dispatch({ type: "ADD_STUDENT", payload: student });
  };
  const removeStudent = (student) => {
    dispatch({ type: "REMOVE_STUDENT", payload: student });
  };
  const addSubject = (subject) => {
    dispatch({ type: "ADD_SUBJECT", payload: subject });
  };
  const removeSubject = (subject) => {
    dispatch({ type: "REMOVE_SUBJECT", payload: subject });
  };
  const changeRound = (round) => {
    dispatch({ type: "CHANGE_ROUND", payload: round });
  };
  const changeBatch = (batch) => {
    dispatch({ type: "CHANGE_BATCH", payload: batch });
  };
  return (
    <div>
      <h1>Hello World</h1>
      <fieldset>
        <legend>Batch Info</legend>
        <ul>
          <li>Round: {state.round}</li>
          <li>Batch: {state.batch}</li>
          <li>Students: {state.students.length}
            <ul>
              {state.students.map((student, index) => (
                <li key={index}>{student} <button type="button" onClick={() => removeStudent(student)}> &times;</button></li>
              ))}
            </ul>
          </li>
          <li>Subjects: {state.subjects.length}
            <ul>
              {state.subjects.map((subject, index) => (
                <li key={index}>{subject} <button type="button" onClick={() => removeSubject(subject)}> &times;</button></li>
              ))}
            </ul>
          </li>
        </ul>
      </fieldset>
      <h2>Form to Update State</h2>
      <fieldset>
        <legend>Add Student</legend>
        <input type="text" placeholder="Enter student name" onChange={(e) => setNewStudent(e.target.value)} value={newStudent} />
        <button type="button" onClick={() => addStudent(newStudent)}>Add Student</button>
      </fieldset>
      <fieldset>
        <legend>Add Subject</legend>
        <input type="text" placeholder="Enter subject name" onChange={(e) => setNewSubject(e.target.value)} value={newSubject} />
        <button type="button" onClick={() => addSubject(newSubject)}>Add Subject</button>
      </fieldset>
      <fieldset>
        <legend>Change Round</legend>
        <input type="number" placeholder="Enter round number" onChange={(e) => setNewRound(e.target.value)} value={newRound} />
        <button type="button" onClick={() => changeRound(newRound)}>Change Round</button>
      </fieldset> 
      <fieldset>
        <legend>Change Batch</legend>
        <input type="text" placeholder="Enter batch name" onChange={(e) => setNewBatch(e.target.value)} value={newBatch} />
        <button type="button" onClick={() => changeBatch(newBatch)}>Change Batch</button>
      </fieldset>
    </div>
  )
}
export default App
