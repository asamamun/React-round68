import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <img src="react.svg" className="logo react" alt="React logo" />     
      <h1>Counter App: current value is  {count}</h1>
      <button onClick={() => setCount(count - 1)}>-</button>      
      <span> {count} </span>
      <button onClick={() => setCount(count + 1)}>+</button>            
    </>
  )
}

export default App
