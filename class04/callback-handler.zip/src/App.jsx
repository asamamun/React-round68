import { useState } from "react";
import Car from './Car.jsx';
import OurForm from './OurForm.jsx';
import Stories from './Stories.jsx';
import stories from './Mystories'; //it will load the stories data from Mystories file
const App = ({c="blue",t="blue color app",id="10"}) => {
    //search is a variable which has default value "testing", it's value can only be set using setSearch method
    const [search, setSearch] = useState("React");
        //handle change function
    const handleChange = (event) => {
       // console.log(event.target.value);
setSearch(event.target.value);
    };
    //filter Stories with search
    const filteredStories = stories.filter((story) => story.title.toLowerCase().includes(search.toLowerCase()));
return (
    <div>
      <h1 style={{"color": c}} title={t}>Hello from App Component</h1>     
       
       <OurForm handleChange={handleChange} search={search} />
       <h1>You want to search: {search} </h1>
       <Stories stories={filteredStories} />       
    </div>

  )
}
export default App;
