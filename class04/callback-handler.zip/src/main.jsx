import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App c="green" t="red color app" id="20" />  
    {/* <App />   */}
{/*     <App c="green" t="green color app" id="21" />  
    <App c="blue" t="blue color app" id="30"/>  */} 
    </StrictMode>,
)
/* const numbers = [1, 2, 3, 4];
const exponentialNumbers = numbers.map(function (number) {
return number * number;
});
console.log(exponentialNumbers); */
