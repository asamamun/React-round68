import Post from './Post';
const Stories = ({stories}) => {
  return (
    <div className='row'>
      {/* {stories.map((story) => <div className='col-md-4' key={story.objectID}>{story.title}</div>)} */}
      {stories.map((story) => <Post key={story.objectID} s={story} />)}
    </div>
    
  );
};
export default Stories;
