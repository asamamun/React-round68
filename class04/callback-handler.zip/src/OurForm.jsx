const OurForm = ({handleChange, search}) => {

    return (
        <form>
            <label htmlFor="name">Name</label>
            <input type="text" id="name" name="name" value={search} onChange={(event)=>handleChange(event)} />            
            <button type="button" value="testSubmit" onClick={(event)=>handleChange(event)}>Submit</button>
        </form>
    );
};
export default OurForm;
