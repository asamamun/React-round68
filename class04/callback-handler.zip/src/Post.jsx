const Post = ({ s }) => {
  return (
    <div className="col-md-4 g-1" >
      <div className="card mb-4 bg-info">
        <div className="card-body">
          <a href={s.url}><h5 className="card-title">{s.title}</h5></a>
          <p>Written by {s.author}</p>
          <p>{s.points} points with {s.num_comments} comments</p>          
        </div>
      </div>
    </div>
  );
};
export default Post;
