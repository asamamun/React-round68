# React অ্যাপ্লিকেশন বিশ্লেষণ - ডাটা ফ্লো এবং কনসেপ্ট

এই ডকুমেন্টেশনে আমরা আমাদের React অ্যাপ্লিকেশনের মাধ্যমে বিভিন্ন মৌলিক ধারণাগুলো বুঝতে চেষ্টা করব।

## 📋 সূচিপত্র
1. [Import এবং Export](#import-এবং-export)
2. [State (স্টেট)](#state-স্টেট)
3. [Props (প্রপস)](#props-প্রপস)
4. [Destructuring (ডিস্ট্রাকচারিং)](#destructuring-ডিস্ট্রাকচারিং)
5. [Event Handler (ইভেন্ট হ্যান্ডলার)](#event-handler-ইভেন্ট-হ্যান্ডলার)
6. [Callback Handler (কলব্যাক হ্যান্ডলার)](#callback-handler-কলব্যাক-হ্যান্ডলার)
7. [পুরো অ্যাপ্লিকেশনের ডাটা ফ্লো](#পুরো-অ্যাপ্লিকেশনের-ডাটা-ফ্লো)

---

## 1. Import এবং Export

### Export (রপ্তানি)
যখন আমরা একটি ফাইল থেকে কোনো Component, Function বা Variable অন্য ফাইলে ব্যবহার করতে চাই, তখন তাকে **Export** করতে হয়।

**উদাহরণ আমাদের প্রজেক্ট থেকে:**

```javascript
// Mystories.js ফাইলে
const stories = [ ... ]; // এখানে stories নামে একটি Array আছে
export default stories;  // এটি Export করা হলো
```

```javascript
// Post.jsx ফাইলে
const Post = ({s }) => { ... };
export default Post;  // Post Component টি Export করা হলো
```

### Import (আমদানি)
অন্য ফাইল থেকে Export করা জিনিস ব্যবহার করার জন্য **Import** করতে হয়।

**উদাহরণ আমাদের প্রজেক্ট থেকে:**

```javascript
// App.jsx ফাইলে
import stories from './Mystories';  // Mystories.js থেকে stories import করা হলো
import OurForm from './OurForm.jsx';  // OurForm.jsx থেকে OurForm component import করা হলো
```

```javascript
// Stories.jsx ফাইলে
import Post from './Post';  // Post.jsx থেকে Post component import করা হলো
```

### নিয়ম:
- `export default` দিয়ে Export করলে, Import করার সময় যেকোনো নাম দেওয়া যায়
- কিন্তু সাধারণত একই নামে Import করা ভালো প্র্যাকটিস
- `import ... from 'path'` - এই syntax ব্যবহার করে Import করতে হয়

---

## 2. State (স্টেট)

### State কী?
State হলো একটি **বিশেষ ভেরিয়েবল** যা React Component এর মধ্যে ডাটা সংরক্ষণ করে এবং সেই ডাটা পরিবর্তনশীল। State পরিবর্তিত হলে Component আবার Render হয়।

### useState Hook
State তৈরি করার জন্য `useState` নামক একটি Hook ব্যবহার করতে হয়।

**আমাদের App.jsx থেকে উদাহরণ:**

```javascript
import { useState } from "react";  // প্রথমে useState import করে নিতে হয়

const App = () => {
    const [search, setSearch] = useState("React");
    // এখানে search হলো state variable
    // setSearch হলো function যা search এর মান পরিবর্তন করে
    // "React" হলো initial value (শুরুর মান)
}
```

### State এর বৈশিষ্ট্য:
1. **search** - বর্তমান মান দেখায় (Current value)
2. **setSearch** - মান পরিবর্তন করার function (Setter function)
3. **useState("React")** - শুরুতে search এর মান "React" থাকবে

### State কিভাবে কাজ করে:
```javascript
// যখনই setSearch ব্যবহার করে search এর মান পরিবর্তন করা হয়
setSearch("Vue");  // তাহলে search এর মান হয়ে যাবে "Vue"
// এবং Component আবার Render হবে
```

---

## 3. Props (প্রপস)

### Props কী?
Props হলো **Parameters** যা Parent Component থেকে Child Component এ পাঠানো হয়। Props এর মাধ্যমে Component গুলোর মধ্যে ডাটা আদান-প্রদান হয়।

### Parent থেকে Child এ Props পাঠানো:

**App.jsx (Parent):**
```javascript
<OurForm handleChange={handleChange} search={search} />
<Stories stories={filteredStories} />
```
এখানে `OurForm` এবং `Stories` component এ props হিসেবে ডাটা পাঠানো হচ্ছে।

### Child Component এ Props গ্রহণ করা:

**OurForm.jsx (Child):**
```javascript
const OurForm = ({handleChange, search}) => {
    // এখানে handleChange এবং search props হিসেবে পাওয়া যাচ্ছে
   return (
        <form>
            <input 
                type="text" 
                value={search}           // Parent থেকে পাওয়া search value
                onChange={(event)=>handleChange(event)}  
            />
        </form>
    );
};
```

**Stories.jsx (Child):**
```javascript
const Stories = ({stories}) => {
    // stories নামক props পাওয়া যাচ্ছে Parent থেকে
   return (
        <div className='row'>
            {stories.map((story) => <Post key={story.objectID} s={story} />)}
        </div>
    );
};
```

### Props এর বৈশিষ্ট্য:
1. Props **Read-only** (এগুলো পরিবর্তন করা যায় না)
2. Parent → Child দিকে প্রবাহিত হয় (একমুখী ডাটা ফ্লো)
3. Function এর parameters এর মতো কাজ করে

---

## 4. Destructuring (ডিস্ট্রাকচারিং)

### Destructuring কী?
Destructuring হলো JavaScript এর একটি আধুনিক পদ্ধতি যার মাধ্যমে Array বা Object থেকে সহজেই values বা properties বের করা যায়।

### Object Destructuring:

**সাধারণ পদ্ধতি:**
```javascript
const person = { name: "Karim", age: 25 };
const name = person.name;  // আগের পদ্ধতি
const age = person.age;
```

**Destructuring পদ্ধতি:**
```javascript
const person = { name: "Karim", age: 25 };
const { name, age } = person;  // এক লাইনেই সব!
```

### আমাদের প্রজেক্টে Destructuring:

**App.jsx এ:**
```javascript
// Props থেকে সরাসরি values বের করা
const App = ({c="blue",t="blue color app", id="10"}) => {
    // এখানে c, t, id - তিনটি props destructuring করে নেওয়া হয়েছে
    // সাথে Default Value ও দেওয়া আছে
}
```

**OurForm.jsx এ:**
```javascript
const OurForm = ({handleChange, search}) => {
    // Parent Component থেকে পাওয়া props destructuring করে নেওয়া হচ্ছে
    // আসলে এটা এমন:
    // const props = {handleChange: ..., search: ...}
    // const handleChange = props.handleChange;
    // const search = props.search;
}
```

**Post.jsx এ:**
```javascript
const Post = ({ s }) => {
    // s নামক props destructuring করা হয়েছে
    // এখানে s হলো একটি story object
   return (
        <div>
            <h5>{s.title}</h5>  // s.title access করা হচ্ছে
            <p>{s.author}</p>   // s.author access করা হচ্ছে
        </div>
    );
};
```

---

## 5. Event Handler (ইভেন্ট হ্যান্ডলার)

### Event Handler কী?
Event Handler হলো এমন একটি Function যা কোনো Event (ক্লিক, চেঞ্জ, সাবমিট ইত্যাদি) ঘটলে Execute হয়।

### আমাদের প্রজেক্টের উদাহরণ:

**App.jsx এ handleChange:**
```javascript
const handleChange = (event) => {
    setSearch(event.target.value);
};
```
এটি একটি Event Handler function যা যেকোনো input event handle করে।

**OurForm.jsx এ Event Handling:**
```javascript
<input 
    type="text" 
    value={search}
    onChange={(event)=>handleChange(event)}  
    // যখনই input এ কিছু টাইপ করা হবে, তখন handleChange call হবে
/>

<button 
    type="button" 
    value="testSubmit" 
    onClick={(event)=>handleChange(event)}
    // যখনই বাটনে ক্লিক করা হবে, তখন handleChange call হবে
>
    Submit
</button>
```

### বিভিন্ন Event Handler:
1. **onChange** - Input এ পরিবর্তন হলে
2. **onClick** - ক্লিক করলে
3. **onSubmit** - Form submit করলে
4. **onMouseEnter** - Mouse উপরে নিলে

### Event Object:
```javascript
const handleChange = (event) => {
    // event হলো একটি Object যা event সম্পর্কিত সব তথ্য রাখে
    event.target        // যে element event trigger করেছে
    event.target.value  // input এর current value
};
```

---

## 6. Callback Handler (কলব্যাক হ্যান্ডলার)

### Callback Function কী?
Callback Function হলো এমন একটি Function যা অন্য Function এর ভেতরে বা অন্য জায়গায় থেকে Call করা হয়।

### আমাদের প্রজেক্টে Callback:

**Step 1: Parent Component এ Handler তৈরি**
```javascript
// App.jsx (Parent)
const handleChange = (event) => {
    setSearch(event.target.value);  // State update করছে
};
```

**Step 2: Child Component এ Props হিসেবে পাঠানো**
```javascript
// App.jsx (Parent)
<OurForm handleChange={handleChange} search={search} />
// handleChange function টি props হিসেবে OurForm এ পাঠানো হলো
```

**Step 3: Child Component এ Callback ব্যবহার**
```javascript
// OurForm.jsx (Child)
const OurForm = ({handleChange, search}) => {
   return (
        <input 
            onChange={(event)=>handleChange(event)}
            // এখানে Parent এর handleChange function call করা হচ্ছে
            // এটি একটি Callback
        />
    );
};
```

### Callback এর কাজের ধারা:
```
User Types in Input 
    ↓
onChange Event Trigger হয়
    ↓
Child Component এ (event)=>handleChange(event) Call হয়
    ↓
Parent Component এর handleChange Function Execute হয়
    ↓
setSearch() দিয়ে State Update হয়
    ↓
Component Re-render হয়
```

### কেন Callback ব্যবহার করি?
1. **Child থেকে Parent এ ডাটা পাঠাতে**
2. **Parent Component এর logic Child এ ব্যবহার করতে**
3. **Code Reusability এর জন্য**

---

## 7. পুরো অ্যাপ্লিকেশনের ডাটা ফ্লো

### ধাপ ১: ডাটা সোর্স (Mystories.js)
```javascript
// Mystories.js ফাইলে ১০টি story এর ডাটা আছে
const stories = [
    { title: 'React', author: 'Jordan Walke', ... },
    { title: 'Redux', author: 'Dan Abramov', ... },
    // ... আরও ৮টি story
];
export default stories;
```

### ধাপ ২: App Component এ ডাটা Import এবং State তৈরি
```javascript
// App.jsx
import stories from './Mystories';  // ডাটা import

const App = () => {
    const [search, setSearch] = useState("React");  // State তৈরি
    
    const handleChange = (event) => {
        setSearch(event.target.value);  // Search state update
    };
    
    // Filter করা stories
    const filteredStories = stories.filter((story) => 
        story.title.toLowerCase().includes(search.toLowerCase())
    );
    
   return (
        <OurForm handleChange={handleChange} search={search} />
        <Stories stories={filteredStories} />
    );
}
```

### ধাপ ৩: OurForm Component এ Search Input
```javascript
// OurForm.jsx
const OurForm = ({handleChange, search}) => {
   return (
        <input 
            value={search}              // App থেকে পাওয়া search value
            onChange={(e)=>handleChange(e)}  // Typing এ handleChange call
        />
    );
};
```

### ধাপ ৪: Stories Component এ Filtered ডাটা প্রদর্শন
```javascript
// Stories.jsx
const Stories = ({stories}) => {
   return (
        {stories.map((story) => 
            <Post key={story.objectID} s={story} />
        )}
    );
};
```

### ধাপ ৫: Post Component এ Individual Story
```javascript
// Post.jsx
const Post = ({ s }) => {
   return (
        <div>
            <h5>{s.title}</h5>
            <p>{s.author}</p>
            <p>{s.points} points</p>
        </div>
    );
};
```

## 🔄 সম্পূর্ণ ডাটা ফ্লো ডায়াগ্রাম

```
┌─────────────────┐
│  Mystories.js   │
│   (ডাটা সোর্স)   │
└────────┬────────┘
         │ export
         ▼
┌─────────────────┐
│     App.jsx     │
│  (Parent Comp.) │
│                 │
│  search State   │◄───(update)───┐
│  handleChange   │               │
│  filteredStories│               │
└────────┬────────┘               │
         │                        │
         │ props                  │ callback
         ▼                        │
┌─────────────────┐               │
│   OurForm.jsx   │───────────────┘
│  (Child Comp.)  │   User types
│                 │   in input
└─────────────────┘
         │
         │ filteredStories (props)
         ▼
┌─────────────────┐
│   Stories.jsx   │
│  (Child Comp.)  │
└────────┬────────┘
         │
         │ map করে প্রতিটি story
         ▼
┌─────────────────┐
│    Post.jsx     │
│  (Child Comp.)  │
└─────────────────┘
```

## 📝 মূল বিষসমূহ

### 1. **Import/Export**
- ডাটা এবং Component এক ফাইল থেকে অন্য ফাইলে নিয়ে যাওয়ার জন্য

### 2. **State**
- Component এর অভ্যন্তরে ডাটা সংরক্ষণ করার জন্য
- `useState` hook ব্যবহার করে তৈরি করতে হয়

### 3. **Props**
- Parent থেকে Child Component এ ডাটা পাঠানোর জন্য
- একমুখী ডাটা ফ্লো (Parent → Child)

### 4. **Destructuring**
- Object বা Array থেকে সহজে values বের করার জন্য
- Code কে ছোট এবং পরিষ্কার রাখে

### 5. **Event Handler**
- User actions (click, change, submit) handle করার জন্য

### 6. **Callback Handler**
- Child Component থেকে Parent Component এ function call করার জন্য
- মূলত Parent এর function Child এ ব্যবহার করার জন্য

---

## 🎯 অনুশীলনী

1. নতুন করে একটি Counter Component তৈরি করুন যেখানে Button click এ count বাড়বে
2. দুটি Child Component তৈরি করুন এবং Parent থেকে Props পাঠান
3. একটি Form তৈরি করুন যা Parent Component এ ডাটা পাঠাবে Callback ব্যবহার করে

---

**লেখক:** আপনার শিক্ষক  
**তারিখ:** March 10, 2026  
**ক্লাস:** React Basics - Class04
