function App() {
  return (
    <>
    <h1>Hello React</h1>
    <hr />
    <h2>Hello from IDB</h2>
    </>
  )
}
export default App
