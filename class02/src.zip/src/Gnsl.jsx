import App from './App.jsx';
import CountryTable from './CountryTable.jsx';
import List from './List.jsx';
const company = "GNSL Technologies";
const welcome = {
greeting: 'Hey',
title: 'React',
};
function footer($title) {
  return `Copyright ${$title}`;
}
function Gnsl() {
    
  return (
    <>
      <h1>Welcome from {company} Component</h1>
      <h2>Much easier(see the code): {welcome.greeting} {welcome.title}</h2>
      <h2>Much harder(see the code): {`${welcome.greeting} ${welcome.title}`}</h2>
      <p>{`in JSX you can apply style using object notation, for example: style={{color : 'red', fontSize :'20px', textAlign :'center', backgroundColor : 'yellow'}}`}</p>
      <p>{`for label's for attribute you can use htmlFor and for class attribute you can use className, for example: <label htmlFor='search' className='form-label'>Search: </label>`}</p>
      <h2 id='fragment' style={{color:'red', fontSize:'20px', textAlign:'center',backgroundColor:'yellow'}}>Short Hand for React.Fragment is &lt;&gt;&lt;/&gt;</h2>
      <hr />
      <App/>
      <hr />
      <label htmlFor="search" title='Search' className='form-label'>Search: </label>
      <input id="search" type="text" />
      <hr />
      <List />
      <CountryTable />
      <footer><mark>{footer(company)}</mark></footer>
    </>
  )
}
export default Gnsl;
