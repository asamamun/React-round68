const car = [
    {name: 'Tesla', year: 2008, color: 'red'},
    {name: 'BMW', year: 2010, color: 'black'},
    {name: 'Mercedes', year: 2015, color: 'white'},
    {name: 'Audi', year: 2018, color: 'blue'},
    {name: 'Honda', year: 2012, color: 'green'},
    {name: 'Battery', year: 2020, color: 'yellow'},
]
function List(){
    return (
        <>
            <h1>Car List</h1>
{/*             {car[0].name} {car[0].year} {car[0].color}<br />
            {car[1].name} {car[1].year} {car[1].color}<br />
            {car[2].name} {car[2].year} {car[2].color}<br />
            {car[3].name} {car[3].year} {car[3].color}<br />
            {car[4].name} {car[4].year} {car[4].color}<br />
            {car[5].name} {car[5].year} {car[5].color}<br /> */}
            {car.map( (v,i)=> <li key={i}>{i} Name: {v.name}, Year: {v.year}, Color: {v.color}</li>)}
        </>
    );
    
}
export default List;
