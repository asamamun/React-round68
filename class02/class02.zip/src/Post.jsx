import postArray from "./postArray.json";
function Post() {
    console.log(postArray);
  return (
    <div className="container mt-4">
      <h1 className="mb-4">Post</h1>
      <div className="row">
        {postArray.posts.map((post) => (
          <div className="col-md-6 mb-4" key={post.id}>
            <div className="card h-100">
              <div className="card-body">
                <h5 className="card-title">{post.title}</h5>
                <p className="card-text">{post.body}</p>
                
                {/* Tags */}
                <div className="mb-3">
                  {post.tags.map((tag, index) => (
                    <span key={index} className="badge bg-secondary me-1">
                      {tag}
                    </span>
                  ))}
                </div>
                
                {/* Reactions */}
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <span className="me-3">
                      <i className="bi bi-hand-thumbs-up"></i> Likes: {post.reactions.likes}
                    </span>
                    <span>
                      <i className="bi bi-hand-thumbs-down"></i> Dislikes: {post.reactions.dislikes}
                    </span>
                  </div>
                  <div>
                    <span className="text-muted">
                      <i className="bi bi-eye"></i> {post.views} views
                    </span>
                  </div>
                </div>
                
                {/* User ID */}
                <div className="mt-3">
                  <small className="text-muted">User ID: {post.userId}</small>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default Post;
