import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import Gnsl from './Gnsl.jsx'


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Gnsl bg="bg-info" title="Gnsl 1" />    
    <Gnsl bg="bg-success" title="Gnsl 2" />    
    <Gnsl bg="bg-warning" title="Gnsl 3" />    
  </StrictMode>,
)
/* const numbers = [1, 2, 3, 4];
const exponentialNumbers = numbers.map(function (number) {
return number * number;
});
console.log(exponentialNumbers); */
