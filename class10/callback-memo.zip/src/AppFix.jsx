import React, { useState, useEffect, useMemo, useCallback } from 'react';
import './index.css';

const ASSET_BASE = "http://192.168.54.121/round68/php/classes/class34Project/Multivendor-E-commerce-in-PHP-MYSQL/";
const API_URL = "http://192.168.54.121/round68/php/classes/class34Project/Multivendor-E-commerce-in-PHP-MYSQL/apis/products.php";

// Child component wrapped in React.memo to prevent unnecessary re-renders
const ProductCounter = React.memo(({ count, onReset }) => {
  console.log("🔥 ProductCounter Rendered!");
  return (
    <div className="card" style={{ marginBottom: '1rem', border: '1px solid #334155' }}>
      <h3>Product Stats Component</h3>
      <p>Count: {count}</p>
      <button className="btn" onClick={onReset} style={{ marginTop: '0.5rem', background: 'var(--accent)' }}>
        Reset Component Counter
      </button>
      <p className="problem-indicator">
        ✅ With useCallback, this only renders when count changes!
      </p>
    </div>
  );
});

const AppFix = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    fetch(API_URL)
      .then(res => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then(data => {
        console.log("✅ Data received:", data);
        // Extract products from nested data structure
        const productsData = data.data?.products || data.products || (Array.isArray(data) ? data : []);
        console.log("✅ Products extracted:", productsData);
        setProducts(productsData);
        setLoading(false);
      })
      .catch(err => {
        console.error("❌ Fetch Error:", err);
        setLoading(false);
      });
  }, []);

  // ✅ SOLUTION: useMemo prevents heavy calculation on every render
  // This only runs when products or searchTerm changes
  const filteredProducts = useMemo(() => {
    console.log("⚙️ Running Heavy Calculation (OPTIMIZED with useMemo)...");
    
    // Simulate heavy computation delay
    const start = Date.now();
    while (Date.now() - start < 100) { /* Busy wait 100ms */ }
    
    return products.filter(p => {
      const productName = p.name || '';
      return productName.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }, [products, searchTerm]); // ← Dependency array: only recalculates when these change!

  // ✅ SOLUTION: useCallback maintains function reference
  // This prevents ProductCounter from re-rendering unnecessarily
  const handleResetCounter = useCallback(() => {
    setCounter(0);
  }, []); // ← Empty dependency array = function never recreated

  return (
    <div className="container">
      <h1>Performance Optimization Hub - FIXED ✅</h1>

      <section className="explanation">
        <h2>Solution Applied</h2>
        <ul>
          <li><strong>useMemo:</strong> Heavy filtering only runs when products or searchTerm changes</li>
          <li><strong>useCallback:</strong> Function reference stays stable, preventing child re-renders</li>
          <li><strong>React.memo:</strong> ProductCounter only re-renders when props actually change</li>
          <li><strong>Result:</strong> Clicking counter doesn't trigger heavy calculations!</li>
        </ul>
      </section>

      <div className="demo-section">
        <div className="card">
          <div className="controls">
            <h3>Optimized with useMemo</h3>
            <div className="input-group">
              <label>Search Products (Triggers Recalculation)</label>
              <input 
                type="text" 
                placeholder="Search..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Unrelated State (Counter)</label>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                <button className="btn" onClick={() => setCounter(c => c + 1)}>Increment: {counter}</button>
                <span className="problem-indicator" style={{ color: '#4ade80' }}>
                  ✅ With useMemo, clicking this does NOT trigger heavy calculation!
                </span>
              </div>
            </div>
          </div>

          <div className="stats">
            <strong>Results found: {filteredProducts.length}</strong>
            <p style={{ fontSize: '0.8rem', marginTop: '0.5rem' }}>
              Calculation source: <code>useMemo(() =&gt; filter, [searchTerm])</code>
            </p>
          </div>
        </div>

        <div className="card">
          <h3>Optimized with useCallback</h3>
          <ProductCounter count={counter} onReset={handleResetCounter} />
          
          <div className="product-grid">
            {loading ? (
              <p>Loading API Data...</p>
            ) : (
              filteredProducts.map(p => (
                <div key={p.id} className="product-item">
                  <img 
                    src={ASSET_BASE + p.primary_image} 
                    alt={p.name} 
                    className="product-image"
                    onError={(e) => { e.target.src = 'https://via.placeholder.com/150?text=Product'; }}
                  />
                  <h4>{p.name}</h4>
                  <p className="price">${p.price}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppFix;
