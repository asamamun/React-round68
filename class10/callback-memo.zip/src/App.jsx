import React, { useState, useEffect } from 'react';
import './index.css';

const ASSET_BASE = "http://192.168.54.121/round68/php/classes/class34Project/Multivendor-E-commerce-in-PHP-MYSQL/";
const API_URL = "http://192.168.54.121/round68/php/classes/class34Project/Multivendor-E-commerce-in-PHP-MYSQL/apis/products.php";

// Child component to demonstrate the problem
const ProductCounter = React.memo(({ count, onReset }) => {
  console.log("🔥 ProductCounter Rendered (wasting resources without useCallback)!");
  return (
    <div className="card" style={{ marginBottom: '1rem', border: '1px solid #334155' }}>
      <h3>Product Stats Component</h3>
      <p>Count: {count}</p>
      <button className="btn" onClick={onReset} style={{ marginTop: '0.5rem', background: 'var(--accent)' }}>
        Reset Component Counter
      </button>
      <p className="problem-indicator">
        ❌ Check console! This renders when typing OR clicking counter because useCallback is missing.
      </p>
    </div>
  );
});

const App = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    fetch(API_URL)
      .then(res => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then(data => {
        console.log("✅ Data received:", data);
        // Extract products from nested data structure
        const productsData = data.data?.products || data.products || (Array.isArray(data) ? data : []);
        console.log("✅ Products extracted:", productsData);
        setProducts(productsData);
        setLoading(false);
      })
      .catch(err => {
        console.error("❌ Fetch Error:", err);
        setLoading(false);
      });
  }, []);

  // ❌ PROBLEM: Heavy calculation runs on EVERY render!
  // Every time ANY state changes (search OR counter), this heavy calculation runs
  // This is what happens WITHOUT useMemo optimization
  console.log("⚙️  Running Heavy Calculation (NO OPTIMIZATION - runs on EVERY render!)...");
  const start = Date.now();
  while (Date.now() - start < 100) { /* Busy wait 100ms */ }
  
  const filteredProducts = products.filter(p => {
    const productName = p.name || '';
    return productName.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // ❌ PROBLEM: Function recreated on every render
  // Without useCallback, this function gets a new reference each time,
  // causing ProductCounter to re-render even with React.memo
  const handleResetCounter = () => {
    setCounter(0);
  };

  return (
    <div className="container">
      <h1>Performance Optimization Hub</h1>

      <section className="explanation">
        <h2>❌ PROBLEM: No Optimization Applied</h2>
        <ul>
          <li><strong>Heavy Calculation Issue:</strong> The product filtering runs on EVERY render - even when clicking the counter!</li>
          <li><strong>Function Recreation:</strong> handleResetCounter is recreated on every render with a new reference.</li>
          <li><strong>Wasted Re-renders:</strong> ProductCounter re-renders unnecessarily because the callback reference changes.</li>
          <li><strong>Performance Impact:</strong> 100ms delay on EVERY action (typing, clicking counter, etc.)</li>
          <li><strong>Solution:</strong> See AppFix.jsx which uses useMemo and useCallback to fix these issues!</li>
        </ul>
      </section>

      <div className="demo-section">
        <div className="card">
          <div className="controls">
            <h3>Optimize with useMemo</h3>
            <div className="input-group">
              <label>Search Products (Triggers Recalculation)</label>
              <input 
                type="text" 
                placeholder="Search..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Unrelated State (Counter)</label>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                <button className="btn" onClick={() => setCounter(c => c + 1)}>Increment: {counter}</button>
                <span className="problem-indicator" style={{ color: '#f87171' }}>
                  ❌ Clicking this triggers heavy calculation! Check console logs.
                </span>
              </div>
            </div>
          </div>

          <div className="stats">
            <strong>Results found: {filteredProducts.length}</strong>
            <p style={{ fontSize: '0.8rem', marginTop: '0.5rem' }}>
              Calculation source: <code>useMemo(() =&gt; filter, [searchTerm])</code>
            </p>
          </div>
        </div>

        <div className="card">
          <h3>Optimize with useCallback</h3>
          <ProductCounter count={counter} onReset={handleResetCounter} />
          
          <div className="product-grid">
            {loading ? (
              <p>Loading API Data...</p>
            ) : (
              filteredProducts.map(p => (
                <div key={p.id} className="product-item">
                  <img 
                    src={ASSET_BASE + p.primary_image} 
                    alt={p.name} 
                    className="product-image"
                    onError={(e) => { e.target.src = 'https://via.placeholder.com/150?text=Product'; }}
                  />
                  <h4>{p.name}</h4>
                  <p className="price">${p.price}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;