# Solution: Optimizing Heavy Calculations with useMemo and useCallback

## The Problem Recap

Every time a user searches or ANY state changes in the component, heavy calculations run unnecessarily:

```javascript
// ❌ WITHOUT OPTIMIZATION
const filteredProducts = products.filter(p => 
  p.name.toLowerCase().includes(searchTerm.toLowerCase())
);
// This runs on EVERY render - even when clicking the counter!
```

**Impact:**
- Searching "laptop" (6 characters) = 6 calculations × 100ms = **600ms freeze**
- Clicking counter 5 times = 5 unnecessary calculations = **500ms wasted**
- Total lag: **1.1 seconds of blocked UI**

---

## The Solution

### Step 1: Use `useMemo` for Heavy Calculations

Memoize the filtered products so they only recalculate when dependencies change:

```javascript
// ✅ WITH useMemo
const filteredProducts = useMemo(() => {
  console.log("⚙️ Running Heavy Calculation...");
  
  // Simulate heavy computation
  const start = Date.now();
  while (Date.now() - start < 100) { /* Busy wait */ }
  
  return products.filter(p => {
    const productName = p.name || '';
    return productName.toLowerCase().includes(searchTerm.toLowerCase());
  });
}, [products, searchTerm]); // ← Only recalculates when these change!
```

**Benefits:**
- ✅ Calculation runs ONLY when `products` or `searchTerm` changes
- ✅ Clicking counter doesn't trigger recalculation
- ✅ Results are cached between renders
- ✅ Instant UI response for unrelated state changes

### Step 2: Use `useCallback` for Function Memoization

Prevent child components from re-rendering unnecessarily:

```javascript
// ✅ WITH useCallback
const handleResetCounter = useCallback(() => {
  setCounter(0);
}, []); // ← Empty array = function never recreated

<ProductCounter count={counter} onReset={handleResetCounter} />
```

**Benefits:**
- ✅ Function reference stays stable across renders
- ✅ `React.memo` can prevent child re-renders
- ✅ No cascading re-renders in component tree

---

## Performance Comparison

### Before Optimization

| Action | Calculation Runs? | Time Wasted |
|--------|------------------|-------------|
| Type "s" | ✅ Yes | 100ms |
| Type "sa" | ✅ Yes | 100ms |
| Type "sam" | ✅ Yes | 100ms |
| Type "sams" | ✅ Yes | 100ms |
| Type "samsu" | ✅ Yes | 100ms |
| Type "samsung" | ✅ Yes | 100ms |
| Click Counter × 5 | ✅ Yes (×5) | 500ms ❌ |
| **Total** | **11 calculations** | **1100ms** |

### After Optimization

| Action | Calculation Runs? | Time Wasted |
|--------|------------------|-------------|
| Type "s" | ✅ Yes | 100ms |
| Type "sa" | ✅ Yes | 100ms |
| Type "sam" | ✅ Yes | 100ms |
| Type "sams" | ✅ Yes | 100ms |
| Type "samsu" | ✅ Yes | 100ms |
| Type "samsung" | ✅ Yes | 100ms |
| Click Counter × 5 | ❌ No | 0ms ✅ |
| **Total** | **6 calculations** | **600ms** |

**Result: 45% performance improvement!** 🎉

---

## Implementation Steps

### 1. Import the Hooks

```javascript
import React, { useState, useEffect, useMemo, useCallback } from 'react';
```

### 2. Wrap Heavy Calculations in `useMemo`

```javascript
const filteredProducts = useMemo(() => {
  console.log("⚙️ Running Heavy Calculation...");
  
  // Your expensive operation here
  return products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
}, [products, searchTerm]);
```

### 3. Wrap Callbacks in `useCallback`

```javascript
const handleResetCounter = useCallback(() => {
  setCounter(0);
}, []);
```

### 4. Wrap Child Components in `React.memo`

```javascript
const ProductCounter = React.memo(({ count, onReset }) => {
  console.log("🔥 ProductCounter Rendered!");
  return (
    <div className="card">
      <h3>Product Stats</h3>
      <p>Count: {count}</p>
      <button onClick={onReset}>Reset</button>
    </div>
  );
});
```

---

## When to Use These Optimizations

### Use `useMemo` when:
- ✅ Filtering large arrays (100+ items)
- ✅ Sorting operations
- ✅ Complex mathematical calculations
- ✅ Data transformations
- ✅ Operations taking >16ms

### Use `useCallback` when:
- ✅ Passing callbacks to `React.memo` components
- ✅ Functions are dependencies of other hooks
- ✅ Preventing unnecessary re-renders
- ✅ Maintaining reference equality

### Don't Over-Optimize:
- ❌ Don't memoize simple calculations (< 1ms)
- ❌ Don't memoize everything "just in case"
- ❌ Don't optimize before profiling first

---

## Code Example

See [`AppFix.jsx`](./src/AppFix.jsx) for the complete optimized implementation.

To use it, simply replace `<App />` with `<AppFix />` in your main entry file.

---

## Testing the Solution

1. **Open Browser Console**
2. **Type in search box**: You should see "⚙️ Running Heavy Calculation..." for each character
3. **Click Counter button**: NO calculation logs should appear ✅
4. **Check ProductCounter**: Should only render when count actually changes

---

## Key Takeaways

1. **Profile First**: Use React DevTools Profiler to find bottlenecks
2. **Memoize Expensive Operations**: Only operations that take significant time
3. **Correct Dependencies**: Always include all dependencies in dependency arrays
4. **Measure Results**: Verify improvements with console logs and profiling
5. **Think in References**: Understand JavaScript object/function references

---

## Additional Resources

- [React Docs: useMemo](https://react.dev/reference/react/useMemo)
- [React Docs: useCallback](https://react.dev/reference/react/useCallback)
- [React Docs: React.memo](https://react.dev/reference/react/memo)
- [React DevTools Profiler Tutorial](https://legacy.reactjs.org/docs/profiler.html)
