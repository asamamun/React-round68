# Problem: Heavy Calculation on Every Search

## The Problem

When a user searches for products in our e-commerce application, the application performs **heavy calculations** on **every single re-render**, not just when the search term changes. This creates significant performance issues.

### What's Happening?

1. **Without `useMemo`**: The product filtering operation runs on EVERY state change
   - When user types in search box → calculation runs ✓ (expected)
   - When user clicks "Increment Counter" → calculation runs ✗ (unnecessary!)
   - When ANY state changes in the component → calculation runs ✗ (wasteful!)

2. **Without `useCallback`**: Functions are recreated on every render
   - Child components (like `ProductCounter`) receive new function references
   - Even with `React.memo`, child components re-render unnecessarily
   - This causes cascading performance issues throughout the component tree

### Real-World Impact

```javascript
// ❌ PROBLEM: Heavy calculation on EVERY render
const filteredProducts = products.filter(p => 
  p.product_title.toLowerCase().includes(searchTerm.toLowerCase())
);
```

**With 1000+ products:**
- Each filter operation takes ~100ms (simulated delay)
- User types "laptop" (5 characters) = 5 calculations = 500ms freeze
- User clicks counter 3 times = 3 MORE calculations = 300ms wasted
- **Total lag: 800ms of unnecessary blocking!**

**User Experience Issues:**
- 🔴 UI freezes while typing
- 🔴 Input lag and stuttering
- 🔴 High CPU usage
- 🔴 Battery drain on mobile devices
- 🔴 Poor accessibility for users with older devices

### Console Evidence

Open your browser console and try this in `App.jsx` (the unoptimized version):

**Test 1: Type "p" in search box**
```
⚙️  Running Heavy Calculation (NO OPTIMIZATION - runs on EVERY render!)...
```
✅ Expected - calculation should run when searching

**Test 2: Click Counter button**
```
⚙️  Running Heavy Calculation (NO OPTIMIZATION - runs on EVERY render!)...
🔥 ProductCounter Rendered (wasting resources without useCallback)!
```
❌ PROBLEM! These shouldn't run when clicking counter!

---

## The Solution

The solution is implemented in [`AppFix.jsx`](./src/AppFix.jsx). To see it in action, replace `<App />` with `<AppFix />` in your main entry file.

### 1. Memoize Heavy Calculations with `useMemo`

```javascript
// ✅ SOLUTION in AppFix.jsx: Only recalculate when dependencies change
const filteredProducts = useMemo(() => {
  console.log("⚙️ Running Heavy Calculation (OPTIMIZED with useMemo)...");
  
  // Simulate heavy computation delay
  const start = Date.now();
  while (Date.now() - start < 100) { /* Busy wait */ }
  
  return products.filter(p => {
    const productName = p.name || '';
    return productName.toLowerCase().includes(searchTerm.toLowerCase());
  });
}, [products, searchTerm]); // ← Only runs when these change!
```

**Benefits:**
- ✅ Calculation only runs when `products` or `searchTerm` changes
- ✅ Clicking counter doesn't trigger recalculation
- ✅ Instant UI response for unrelated state changes
- ✅ Cached result is reused until dependencies change

### 2. Memoize Callbacks with `useCallback`

```javascript
// ✅ SOLUTION in AppFix.jsx: Maintain function reference equality
const handleResetCounter = useCallback(() => {
  setCounter(0);
}, []); // ← Empty dependency array = never recreated
```

**Benefits:**
- ✅ Function reference stays the same across renders
- ✅ `React.memo` can properly prevent child re-renders
- ✅ No unnecessary re-renders of `ProductCounter`
- ✅ Better performance for deeply nested components

---

## Before vs After Comparison

### ❌ Before (No Optimization)

| Action | Calculation Runs? | Child Re-renders? | Performance |
|--------|------------------|-------------------|-------------|
| Type "p" | ✅ Yes | ✅ Yes | 😞 Slow |
| Type "ph" | ✅ Yes | ✅ Yes | 😞 Slow |
| Type "pho" | ✅ Yes | ✅ Yes | 😞 Slow |
| Click Counter | ✅ Yes (unnecessary!) | ✅ Yes | 😞 Wasted |
| Click Counter | ✅ Yes (unnecessary!) | ✅ Yes | 😞 Wasted |

**Total: 5 calculations, 5 re-renders**

### ✅ After (With Optimization)

| Action | Calculation Runs? | Child Re-renders? | Performance |
|--------|------------------|-------------------|-------------|
| Type "p" | ✅ Yes | ✅ Yes | 🙂 Expected |
| Type "ph" | ✅ Yes | ✅ Yes | 🙂 Expected |
| Type "pho" | ✅ Yes | ✅ Yes | 🙂 Expected |
| Click Counter | ❌ No | ❌ No | 🎉 Fast! |
| Click Counter | ❌ No | ❌ No | 🎉 Fast! |

**Total: 3 calculations (only when needed), 0 wasted re-renders**

---

## Implementation Guide

### When to Use `useMemo`

Use for expensive computations:
- Filtering large arrays
- Sorting operations
- Complex mathematical calculations
- Data transformations
- Any operation that takes >16ms (1 frame at 60fps)

```javascript
const memoizedValue = useMemo(() => {
  // Expensive operation
  return computeExpensiveValue(a, b);
}, [a, b]);
```

### When to Use `useCallback`

Use for:
- Passing callbacks to optimized child components (`React.memo`)
- Functions used as dependencies in other hooks
- Event handlers passed to child components
- Preventing unnecessary re-creation of functions

```javascript
const memoizedCallback = useCallback(() => {
  doSomething(a, b);
}, [a, b]);
```

---

## Key Takeaways

1. **Profile First**: Use React DevTools Profiler to identify performance bottlenecks
2. **Memoize Strategically**: Not everything needs memoization—only expensive operations
3. **Dependencies Matter**: Always include correct dependencies in dependency arrays
4. **Measure Impact**: Check console logs and render counts to verify improvements
5. **Think in References**: Understand when JavaScript creates new references vs. reusing existing ones

---

## Additional Resources

- [React Docs: useMemo](https://react.dev/reference/react/useMemo)
- [React Docs: useCallback](https://react.dev/reference/react/useCallback)
- [React Docs: React.memo](https://react.dev/reference/react/memo)
- [React DevTools Profiler](https://legacy.reactjs.org/docs/profiler.html)
