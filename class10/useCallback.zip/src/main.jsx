import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import WithoutCallbackExample from './App2.jsx'
import WithCallbackExample from './App3.jsx'

createRoot(document.getElementById('root')).render(
  <>
  <App />
  <WithoutCallbackExample/>
  <WithCallbackExample />
  </>
)
