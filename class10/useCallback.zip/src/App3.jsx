//With useCallback:
import React, { useState, useCallback } from 'react';


// Child component that receives a function prop
const Button = React.memo(({ onClick, text }) => {
  alert(`${text} button rendered`);
  return <button onClick={onClick}>{text}</button>;
});

// Parent component with useCallback
function WithCallbackExample() {
  const [count1, setCount1] = useState(0);
  const [count2, setCount2] = useState(0);

  // These functions are memoized and only recreated when dependencies change
  const handleClick1 = useCallback(() => {
    setCount1(count1 + 1);
  }, [count1]);
/*   const handleClick1 = () => {
    setCount1(count1 + 1);
  }; */


  const handleClick2 = useCallback(() => {
    setCount2(count2 + 1);
  }, [count2]);
/*   const handleClick2 = () => {
    setCount2(count2 + 1);
  }; */

  alert("Parent rendered");
  return (
    <div>
      <h2>With useCallback:</h2>
      <p>Clicking button 1 does not render button 2 and its function because handleClick2 is not called</p>
      <p>Clicking button 2 does not render button 1 and its function because handleClick1 is not called</p>
      <p>handleClick1 and handleClick2 are memoized functions that are only recreated when their dependencies change</p>
      <p>these 2 functions have simple increment logic but think what if it fetches data from an API or does more complex logic!!! it that case, useCallback can help to optimize performance by preventing unnecessary re-renders of child components. this way your heavy function calculations are only done when necessary</p>
      <p>Count 1: {count1}</p>
      <p>Count 2: {count2}</p>
      <Button onClick={handleClick1} text="Button 1" />
      <Button onClick={handleClick2} text="Button 2" />
    </div>
  );
}

export default WithCallbackExample;
