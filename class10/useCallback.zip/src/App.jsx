import { useState, useCallback, memo } from 'react';

// Child component that receives a function as prop
const ChildComponent = memo(({ onButtonClick, name }) => {
  console.log(`${name} rendered`);
  return (
    <div style={{ margin: '10px', padding: '10px', border: '1px solid #ccc' }}>
      <h3>{name}</h3>
      <button onClick={onButtonClick}>Click Me</button>
    </div>
  );
});

function App() {
  const [count, setCount] = useState(0);
  const [text, setText] = useState('');

  // ❌ WITHOUT useCallback: Function is recreated on every render
  // This causes unnecessary re-renders of child components
  const handleClickWithoutCallback = () => {
    console.log('Button clicked! Count:', count);
    setCount(count + 1);
  };

  // ✅ WITH useCallback: Function is memoized and only recreated when dependencies change
  // This prevents unnecessary re-renders of child components
  const handleClickWithCallback = useCallback(() => {
    console.log('Button clicked! Count:', count);
    setCount(count + 1);
  }, [count]); // Only recreate when 'count' changes

  // ✅ useCallback with multiple dependencies
  const handleTextChange = useCallback((e) => {
    setText(e.target.value);
    console.log('Text changed to:', e.target.value);
  }, []); // No dependencies, so never recreated

  // ✅ useCallback that accepts parameters
  const handleAlert = useCallback((message) => {
    alert(message);
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>useCallback Hook Example</h1>
      
      {/* Definition of useCallback */}
      <div style={{ background: '#f0f0f0', padding: '15px', marginBottom: '20px', borderRadius: '5px' }}>
        <h3>📚 What is useCallback?</h3>
        <p><strong>useCallback</strong> is a React hook that returns a memoized version of a function.</p>
        <p><strong>Syntax:</strong> <code>const memoizedFunction = useCallback(() =&gt; {'{'} /* logic */ {'}'}, [dependencies]);</code></p>
        <p><strong>Purpose:</strong> Prevents function recreation on every render, optimizing performance by preventing unnecessary re-renders of child components.</p>
        <ul>
          <li>Without useCallback: Function is created fresh on every render</li>
          <li>With useCallback: Function is cached and only recreated when dependencies change</li>
        </ul>
      </div>

      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        {/* Example WITHOUT useCallback */}
        <div style={{ flex: 1 }}>
          <h2>❌ Without useCallback</h2>
          <p>This function recreates on every render, causing child to re-render unnecessarily!</p>
          <ChildComponent 
            name="Without useCallback" 
            onButtonClick={handleClickWithoutCallback} 
          />
        </div>

        {/* Example WITH useCallback */}
        <div style={{ flex: 1 }}>
          <h2>✅ With useCallback</h2>
          <p>This function is memoized, preventing unnecessary child re-renders!</p>
          <ChildComponent 
            name="With useCallback" 
            onButtonClick={handleClickWithCallback} 
          />
        </div>
      </div>

      <div style={{ marginTop: '20px' }}>
        <h2>Other Examples</h2>
        
        {/* Text input with useCallback */}
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>Text Input (useCallback with event):</strong>
            <input 
              type="text" 
              value={text} 
              onChange={handleTextChange}
              style={{ marginLeft: '10px', padding: '5px' }}
              placeholder="Type something..."
            />
          </label>
          <p>Current text: {text || '(empty)'}</p>
        </div>

        {/* Button with parameter */}
        <div>
          <button 
            onClick={() => handleAlert('Hello from useCallback!')}
            style={{ padding: '10px 20px', background: '#4CAF50', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
          >
            Show Alert
          </button>
        </div>
      </div>

      <div style={{ marginTop: '30px', padding: '15px', background: '#e7f3ff', borderRadius: '5px' }}>
        <h3>💡 Key Points:</h3>
        <ul>
          <li><strong>Use useCallback when:</strong> Passing functions to child components that are wrapped in React.memo</li>
          <li><strong>Benefits:</strong> Prevents unnecessary re-renders and maintains referential equality</li>
          <li><strong>Dependencies:</strong> The function only updates when values in the dependency array change</li>
          <li><strong>Empty dependency array []:</strong> Function is created once and never updated</li>
        </ul>
      </div>
    </div>
  );
}

export default App;