import { useState, useMemo } from 'react'

// Example 1: WITHOUT useMemo (inefficient)
function WithoutUseMemo() {
  const [count, setCount] = useState(0)
  const [toggle, setToggle] = useState(false)

  // This expensive calculation runs on EVERY render
  // Even when toggle changes but count doesn't
  const expensiveCalculation = () => {
    console.log('Calculating without useMemo...')
    let result = 0
    for (let i = 0; i < 1000000000; i++) {
      result += i
    }
    return result * count
  }

  const calculatedValue = expensiveCalculation()

  return (
    <div style={{ border: '2px solid red', padding: '20px', margin: '20px' }}>
      <h2>Without useMemo</h2>
      <p>Count: {count}</p>
      <p>Calculated Value: {calculatedValue}</p>
      <button onClick={() => setCount(count + 1)}>Increment Count</button>
      <br /><br />
      <button onClick={() => setToggle(!toggle)}>
        Toggle (triggers recalculation - inefficient!)
      </button>
      <p>Toggle State: {toggle ? 'ON' : 'OFF'}</p>
    </div>
  )
}

// Example 2: WITH useMemo (optimized)
function WithUseMemo() {
  const [count, setCount] = useState(0)
  const [toggle, setToggle] = useState(false)

  // This expensive calculation ONLY runs when count changes
  // When toggle changes, the cached value is returned
  const calculatedValue = useMemo(() => {
    console.log('Calculating with useMemo...')
    let result = 0
    for (let i = 0; i < 1000000000; i++) {
      result += i
    }
    return result * count
  }, [count]) // Only recalculate when count changes

  return (
    <div style={{ border: '2px solid green', padding: '20px', margin: '20px' }}>
      <h2>With useMemo</h2>
      <p>Count: {count}</p>
      <p>Calculated Value: {calculatedValue}</p>
      <button onClick={() => setCount(count + 1)}>Increment Count</button>
      <br /><br />
      <button onClick={() => setToggle(!toggle)}>
        Toggle (no recalculation - optimized!)
      </button>
      <p>Toggle State: {toggle ? 'ON' : 'OFF'}</p>
    </div>
  )
}

// Definition of useMemo:
// useMemo is a React hook that memoizes a computed value.
// It caches the result of a function call and only recalculates when dependencies change.
// Syntax: useMemo(() => { computation }, [dependencies])
// Benefits: 
//   - Prevents expensive calculations on every render
//   - Optimizes performance
//   - Returns the same value unless dependencies change

function App() {
  return (
    <div className="App">
      <h1>useMemo Hook Examples</h1>
      <p>Open console to see the difference in calculations!</p>
      <fieldset>
        <legend>In Without useMemo component</legend>
        <p>Here, changing toggle value should not call the expensive calculation. expensive calculation should only be called when count value changes. But it is not the case here. You can check the console to see the calculations. toggle button is calling the expensive calculation. But it should not.</p>
      </fieldset>
      <fieldset>
        <legend>In With useMemo component</legend>
        <p>Here, changing toggle value is not calling the expensive calculation. the expensive calculation function is inside useMemo hook. and its dependency is count. so it only recalculates when count changes. toggle button will not call the expensive calculation. because its dependency count value is not changing.</p>
      </fieldset>
      
      {/* WITHOUT useMemo - Inefficient */}
      <WithoutUseMemo />
      
      {/* WITH useMemo - Optimized */}
      <WithUseMemo />
    </div>
  )
}

export default App