const Car = ({color="yellow", brandName="DholaiKhal", brandColor="black"}) => {
    return (
        <div className="car-container">
            {/* svg car image with color and brand name passed as props */}
            <svg className="car" width="200" height="120" viewBox="0 0 200 120">
                {/* Car Body */}
                <path 
                    d="M 20 70 L 20 90 L 40 90 L 45 60 L 70 45 L 130 45 L 155 60 L 160 90 L 180 90 L 180 70 L 160 70 L 155 55 L 130 40 L 70 40 L 45 55 L 40 70 Z" 
                    fill={color} 
                    stroke="#333" 
                    strokeWidth="2"
                />
                {/* Car Roof/Window */}
                <path 
                    d="M 50 58 L 55 48 L 145 48 L 150 58 Z" 
                    fill="#87CEEB" 
                    opacity="0.7"
                    stroke="#333" 
                    strokeWidth="2"
                />
                {/* Wheel Left */}
                <circle cx="50" cy="90" r="12" fill="#333" />
                <circle cx="50" cy="90" r="6" fill="#silver" />
                {/* Wheel Right */}
                <circle cx="150" cy="90" r="12" fill="#333" />
                <circle cx="150" cy="90" r="6" fill="#silver" />
                {/* Headlight */}
                <ellipse cx="175" cy="75" rx="5" ry="8" fill="#FFFFE0" />
                {/* Taillight */}
                <rect x="22" y="72" width="6" height="10" fill="#FF6347" />
                {/* Brand Label */}
                <text x="95" y="68" fill={brandColor} fontSize="10" fontWeight="bold" textAnchor="middle">{brandName}</text>
            </svg>
        </div>
    )
}
export default Car;

