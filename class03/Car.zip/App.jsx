import Car from './Car.jsx';
const App = ({c,t}) => {
    const carArray = [
        {'color': 'red', 'brandName': 'Toyota', 'brandColor': 'chocolate'},
        {'color': 'blue', 'brandName': 'Honda', 'brandColor': 'black'},
        {'color': 'green', 'brandName': 'Ford', 'brandColor': 'blue'},
        {'color': 'yellow', 'brandName': 'Chevrolet', 'brandColor': 'black'},
        {'color': 'black', 'brandName': 'Tesla', 'brandColor': 'red'},
        {'color': 'white', 'brandName': 'BMW', 'brandColor': 'maroon'},
        {'color': 'gray', 'brandName': 'Mercedes-Benz', 'brandColor': 'blue'},
        {'color': 'purple', 'brandName': 'Audi', 'brandColor': 'blue'},
        {'color': 'orange', 'brandName': 'Volkswagen', 'brandColor': 'maroon'},
        {'color': 'brown', 'brandName': 'Porsche', 'brandColor': 'red'},
        {'color': 'charcoal'}
    ];
return (
    <div>
      <h1 style={{"color": c}} title={t}>Hello from App Component</h1>
      <hr />
      {/* <Car color="green" brandName="Toyota" brandColor="red"></Car> */}
      {/* <Car color="blue" brandName="Honda" brandColor="black"></Car> */}
      {carArray.map((car,i)=>(
        <Car key={i} color={car.color} brandName={car.brandName} brandColor={car.brandColor}></Car>
       ))}
    </div>

  )
}
export default App;
