import React, { useState } from 'react';
const StudentForm = () => {
    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(inputs);
    }
    const [inputs, setInputs] = useState({});
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        
        setInputs(values => ({...values, [name]: value}))
        console.log(inputs)
    }

  return (
    <>
    <div>Student Form</div>
    <form onSubmit={handleSubmit}>
      <label>
        First Name:
        <input type="text" name="firstName" value={inputs.firstName || ""} onChange={handleChange} />
      </label>
      <label>
        Last Name:
        <input type="text" name="lastName" value={inputs.lastName || ""} onChange={handleChange} />
      </label>
      <label>
        Email:
        <input type="email" name="email" value={inputs.email || ""} onChange={handleChange} />
      </label>
      <label>
        Phone Number:
        <input type="tel" name="phoneNumber" value={inputs.phoneNumber || ""} onChange={handleChange} />
      </label>
      <label>
        Date of Birth:
        <input type="date" name="dob" value={inputs.dob || ""} onChange={handleChange} />
      </label>
      <label>
        Gender:
        <select name="gender" value={inputs.gender || ""} onChange={handleChange}>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </label>
      <button type="submit">Submit</button>
    </form>
    </>
  );
};
export default StudentForm;
