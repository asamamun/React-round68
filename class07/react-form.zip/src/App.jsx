
import StudentForm from './StudentForm';
const App = () => {
  return (
    <>
      <div>App</div>
      <StudentForm />
    </>
  );
};
export default App;
