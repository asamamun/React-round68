const Box = (props) => {
  return (
    <div className="custombox" style={{background: props.children}}>
      
    </div>
  )
}
export default Box
