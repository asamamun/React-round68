import { useState } from "react";
const ContactForm = () => {
    const [name, setName] = useState("A");
    const [email, setEmail] = useState("B@g.com");
    const [message, setMessage] = useState("C");
    
    
  return (
    <div>
      <h2>Contact Form: {name} {email} {message}</h2>
      <form>
        <label>Enter your name:
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <hr />
        <label>Enter your email:
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <hr />
        <label>Enter your message:
          <textarea value={message} onChange={(e) => setMessage(e.target.value)} />
        </label>
        <hr />
        <button>Submit</button>
      </form>
    </div>
  );
};
export default ContactForm;
