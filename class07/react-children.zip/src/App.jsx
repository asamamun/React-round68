import Son from "./Son"
import Daughter from "./Daughter" 
import Box from "./Box";
import ContactForm from "./ContactForm";

const App = () => {  
  return (
  <div>
    App1
    <Daughter>
    <ul><li>Item 3</li><li>Item 4</li></ul>
    <hr />
    <p>
      This was written in the Parent component,
      but displayed as a part of the Daughter component because it is passed as children to the Daughter component
    </p>
  </Daughter>
  <hr />
  <Daughter>
    <marquee behavior="" direction="">testing children</marquee>
  </Daughter>
  <Son>
    <ul><li>Item 1</li><li>Item 2</li></ul>
    <hr />
    <p>
        This was written in the Parent component,
        but displayed as a part of the Son component because it is passed as children to the Son component
      </p>
  </Son>
  
  <Box>Red</Box> 
  <Box>Blue</Box> 
  <Box>Green</Box> 
  <Box>Yellow</Box>
  <hr />
  <h3>React Forms</h3>
  <ContactForm />
  </div>
  );
}
export default App
