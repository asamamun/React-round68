const Son = (props) => {
  return (
    <div style={{background: 'lightgreen'}}>
      <h2>Son</h2>
      <p>
        {props.children}
      </p>
    </div>
  )
}
export default Son
