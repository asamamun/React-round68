const Daughter = (props) => {
  return (
    <div style={{background: 'lightblue'}}>
      <h2>Daughter</h2>
      <hr />
      <p>
        {props.children}
      </p>
    </div>
  )
}
export default Daughter
