import { createContext, useState } from 'react';
import Component2 from './Component2.jsx';

// Create and export the UserContext
//this component provides the user context to its children, it is not nested inside any other component
export const UserContext = createContext();

const Appp = () => {
    const [user, setUser] = useState("Linus");
    const [color, setColor] = useState("green");
    return (
        <div>
            <UserContext.Provider value={{ user, color }}>
                <h1>Hello from Appp</h1>
                <Component2 />
            </UserContext.Provider>
            
            <h3>How Context API Works Here</h3>
            <section style={{ 
                padding: '20px', 
                backgroundColor: '#f0f8ff', 
                borderRadius: '8px',
                marginTop: '15px',
                border: '2px solid #4682b4'
            }}>
                <h4 style={{ color: '#4682b4', marginBottom: '15px' }}>📚 Understanding Context API - No More Prop Drilling!</h4>
                
                <div style={{ marginBottom: '20px' }}>
                    <h5 style={{ color: '#2c5282' }}>❌ The Problem (Prop Drilling):</h5>
                    <p style={{ lineHeight: '1.6' }}>
                        Without Context API, we would need to pass <code>user</code> as a prop through every intermediate component:
                    </p>
                    <div style={{ 
                        backgroundColor: '#fff', 
                        padding: '15px', 
                        borderRadius: '5px',
                        fontFamily: 'monospace',
                        fontSize: '13px',
                        borderLeft: '4px solid #e53e3a'
                    }}>
                        <p>Appp → passes user prop → Component2 → passes user prop → Component3</p>
                    </div>
                </div>

                <div style={{ marginBottom: '20px' }}>
                    <h5 style={{ color: '#2c5282' }}>✅ The Solution (Context API):</h5>
                    <p style={{ lineHeight: '1.6' }}>
                        With Context API, we create a "tunnel" that any component can access directly:
                    </p>
                    <div style={{ 
                        backgroundColor: '#fff', 
                        padding: '15px', 
                        borderRadius: '5px',
                        fontFamily: 'monospace',
                        fontSize: '13px',
                        borderLeft: '4px solid #48bb78'
                    }}>
                        <p>Appp (Provider) → Context → Component3 (Consumer)</p>
                        <p style={{ marginTop: '10px', color: '#48bb78' }}>✓ Component2 doesn't need to know about or pass the user prop!</p>
                    </div>
                </div>

                <div style={{ marginBottom: '20px' }}>
                    <h5 style={{ color: '#2c5282' }}>🔧 How It Works in This Example:</h5>
                    <ol style={{ lineHeight: '2', paddingLeft: '20px' }}>
                        <li>
                            <strong>Step 1: Create Context</strong>
                            <div style={{ 
                                backgroundColor: '#2d3748', 
                                color: '#68d391', 
                                padding: '10px', 
                                borderRadius: '5px',
                                fontFamily: 'monospace',
                                fontSize: '12px',
                                marginTop: '5px'
                            }}>
                                export const UserContext = React.createContext();
                            </div>
                        </li>
                        <li style={{ marginTop: '15px' }}>
                            <strong>Step 2: Provide the Value</strong> (in Appp.jsx)
                            <div style={{ 
                                backgroundColor: '#2d3748', 
                                color: '#68d391', 
                                padding: '10px', 
                                borderRadius: '5px',
                                fontFamily: 'monospace',
                                fontSize: '12px',
                                marginTop: '5px'
                            }}>
                                &lt;UserContext.Provider value={'{'}user{'}'}&gt;<br/>
                                &nbsp;&nbsp;{'<Component2 />'}<br/>
                                &lt;/UserContext.Provider&gt;
                            </div>
                        </li>
                        <li style={{ marginTop: '15px' }}>
                            <strong>Step 3: Consume the Value</strong> (in Component3.jsx)
                            <div style={{ 
                                backgroundColor: '#2d3748', 
                                color: '#68d391', 
                                padding: '10px', 
                                borderRadius: '5px',
                                fontFamily: 'monospace',
                                fontSize: '12px',
                                marginTop: '5px'
                            }}>
                                import {'{'} UserContext {'}'} from './Appp.jsx';<br/>
                                const user = useContext(UserContext);
                            </div>
                        </li>
                    </ol>
                </div>

                <div style={{ 
                    backgroundColor: '#fffaf0', 
                    padding: '15px', 
                    borderRadius: '5px',
                    borderLeft: '4px solid #ed8936'
                }}>
                    <h5 style={{ color: '#dd6b20', marginBottom: '10px' }}>💡 Key Benefits:</h5>
                    <ul style={{ lineHeight: '1.8' }}>
                        <li>✅ <strong>No Prop Drilling:</strong> Intermediate components don't need to pass props they don't use</li>
                        <li>✅ <strong>Cleaner Code:</strong> Components only receive data they actually need</li>
                        <li>✅ <strong>Global Access:</strong> Any component in the tree can access the context</li>
                        <li>✅ <strong>Easy Updates:</strong> Changing the context value automatically updates all consumers</li>
                    </ul>
                </div>

                <div style={{ 
                    marginTop: '20px',
                    padding: '15px',
                    backgroundColor: '#faf5ff',
                    borderRadius: '5px',
                    border: '2px dashed #9f7aea'
                }}>
                    <h5 style={{ color: '#805ad5' }}>🎯 Current Example Flow:</h5>
                    <div style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'space-between',
                        flexWrap: 'wrap',
                        gap: '10px',
                        marginTop: '10px'
                    }}>
                        <div style={{ 
                            backgroundColor: '#667eea', 
                            color: 'white', 
                            padding: '10px 15px', 
                            borderRadius: '5px',
                            fontWeight: 'bold'
                        }}>
                            📦 Appp.jsx<br/>
                            <small>Provider (value="Linus")</small>
                        </div>
                        <div style={{ fontSize: '20px' }}>→</div>
                        <div style={{ 
                            backgroundColor: '#ed64a6', 
                            color: 'white', 
                            padding: '10px 15px', 
                            borderRadius: '5px',
                            fontWeight: 'bold'
                        }}>
                            🔵 UserContext
                        </div>
                        <div style={{ fontSize: '20px' }}>→</div>
                        <div style={{ 
                            backgroundColor: '#48bb78', 
                            color: 'white', 
                            padding: '10px 15px', 
                            borderRadius: '5px',
                            fontWeight: 'bold'
                        }}>
                            🎯 Component3.jsx<br/>
                            <small>Consumer (receives "Linus")</small>
                        </div>
                    </div>
                    <p style={{ marginTop: '15px', fontStyle: 'italic', color: '#555' }}>
                        🔍 Notice: Component2 is in the middle but doesn't need to handle the user prop at all!
                    </p>
                </div>
            </section>
        </div>
    );
};
export default Appp;
