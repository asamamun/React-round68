import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import ContextAPIExample from './pages/ContextAPIExample';
import UseRefExample from './pages/UseRefExample';
import UseReducerExample from './pages/UseReducerExample';

const App = () => {
  const styles = {
    nav: {
      backgroundColor: '#333',
      padding: '15px 30px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    },
    logo: {
      color: '#fff',
      fontSize: '24px',
      fontWeight: 'bold',
      textDecoration: 'none',
    },
    navLinks: {
      display: 'flex',
      gap: '20px',
    },
    navLink: {
      color: '#fff',
      textDecoration: 'none',
      padding: '8px 16px',
      borderRadius: '4px',
      transition: 'background-color 0.3s ease',
    },
    content: {
      minHeight: 'calc(100vh - 60px)',
      backgroundColor: '#f5f5f5',
    },
  };

  return (
    <Router>
      <div>
        {/* Navigation Bar */}
        <nav style={styles.nav}>
          <Link to="/" style={styles.logo}>
            ⚛️ React Examples
          </Link>
          <div style={styles.navLinks}>
            <Link to="/" style={styles.navLink}>
              🏠 Home
            </Link>
            <Link to="/context-api" style={styles.navLink}>
              🔷 Context API
            </Link>
            <Link to="/use-ref" style={styles.navLink}>
              📌 useRef
            </Link>
            <Link to="/use-reducer" style={styles.navLink}>
              🔄 useReducer
            </Link>
          </div>
        </nav>

        {/* Main Content */}
        <div style={styles.content}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/context-api" element={<ContextAPIExample />} />
            <Route path="/use-ref" element={<UseRefExample />} />
            <Route path="/use-reducer" element={<UseReducerExample />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
