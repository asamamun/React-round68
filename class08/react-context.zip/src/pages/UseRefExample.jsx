import { useRef, useState } from 'react';

const UseRefExample = () => {
  const inputRef = useRef(null);
  const countRef = useRef(0);
  const [count, setCount] = useState(0);
  const [renderCount, setRenderCount] = useState(0);

  // Track renders using useRef (doesn't trigger re-renders)
  const renderTracker = useRef(0);
  renderTracker.current += 1;

  const focusInput = () => {
    inputRef.current?.focus();
  };

  const clearInput = () => {
    inputRef.current.value = '';
  };

  // Demonstrating useRef for mutable values that don't cause re-renders
  const incrementRef = () => {
    countRef.current += 1;
    alert(`Count Ref Value: ${countRef.current}\n(This doesn't trigger a re-render!)`);
  };

  // Regular state update that triggers re-render
  const incrementState = () => {
    setCount((prev) => prev + 1);
  };

  const styles = {
    container: {
      maxWidth: '800px',
      margin: '0 auto',
      padding: '20px',
    },
    header: {
      textAlign: 'center',
      marginBottom: '30px',
    },
    section: {
      marginBottom: '30px',
    },
    codeBlock: {
      backgroundColor: '#f4f4f4',
      padding: '15px',
      borderRadius: '5px',
      overflowX: 'auto',
      fontFamily: 'monospace',
      fontSize: '14px',
    },
    input: {
      padding: '10px',
      fontSize: '16px',
      border: '2px solid #ccc',
      borderRadius: '4px',
      marginRight: '10px',
      width: '250px',
    },
    button: {
      padding: '10px 20px',
      backgroundColor: '#007bff',
      color: '#ffffff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      marginRight: '10px',
      marginTop: '10px',
    },
    secondaryButton: {
      padding: '10px 20px',
      backgroundColor: '#28a745',
      color: '#ffffff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      marginRight: '10px',
      marginTop: '10px',
    },
    infoBox: {
      backgroundColor: '#e7f3ff',
      padding: '15px',
      borderRadius: '5px',
      borderLeft: '4px solid #007bff',
      marginBottom: '20px',
    },
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>📌 useRef Hook Example</h1>

      <div style={styles.section}>
        <h2>Definition</h2>
        <p>
          The useRef hook returns a mutable ref object whose .current property is initialized 
          to the passed argument (initialValue). The returned object will persist for the full 
          lifetime of the component. Importantly, <strong>ref changes do not trigger re-renders</strong>.
        </p>
      </div>

      <div style={styles.section}>
        <h2>Purpose</h2>
        <ul>
          <li><strong>Accessing DOM Elements:</strong> Direct access to DOM nodes for focus, selection, or measurements</li>
          <li><strong>Storing Mutable Values:</strong> Keep track of values without causing re-renders</li>
          <li><strong>Preserving Values Across Renders:</strong> Maintain references between renders without triggering updates</li>
          <li><strong>Working with Timers/Intervals:</strong> Store timer IDs without triggering re-renders</li>
        </ul>
      </div>

      <div style={styles.infoBox}>
        <strong>⚠️ Key Difference from useState:</strong> Changing a ref value doesn't trigger a re-render, 
        while changing state does!
      </div>

      <div style={styles.section}>
        <h2>Live Example 1: DOM Access</h2>
        <p>Use useRef to directly access and manipulate DOM elements:</p>
        <input
          type="text"
          ref={inputRef}
          placeholder="Click buttons below to interact"
          style={styles.input}
        />
        <br />
        <button onClick={focusInput} style={styles.button}>
          Focus Input
        </button>
        <button onClick={clearInput} style={styles.secondaryButton}>
          Clear Input
        </button>
      </div>

      <div style={styles.section}>
        <h2>Live Example 2: useRef vs useState</h2>
        <p>Compare how useRef and useState behave differently:</p>
        
        <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '250px', padding: '15px', border: '2px solid #28a745', borderRadius: '8px' }}>
            <h3>useState (Triggers Re-render)</h3>
            <p>Current Count: <strong>{count}</strong></p>
            <button onClick={incrementState} style={styles.button}>
              Increment State (+{count})
            </button>
            <p style={{ fontSize: '12px', marginTop: '10px' }}>
              Each click updates state and re-renders the component
            </p>
          </div>

          <div style={{ flex: 1, minWidth: '250px', padding: '15px', border: '2px solid #007bff', borderRadius: '8px' }}>
            <h3>useRef (No Re-render)</h3>
            <p>Current Ref Value: <strong>{countRef.current}</strong></p>
            <button onClick={incrementRef} style={styles.secondaryButton}>
              Increment Ref
            </button>
            <p style={{ fontSize: '12px', marginTop: '10px' }}>
              Value updates but component doesn't re-render!
            </p>
          </div>
        </div>
      </div>

      <div style={styles.section}>
        <h2>Render Counter</h2>
        <div style={{ padding: '15px', backgroundColor: '#fff3cd', borderRadius: '5px' }}>
          <p><strong>Total Component Renders:</strong> {renderTracker.current}</p>
          <p style={{ fontSize: '14px' }}>
            Notice: Clicking "Increment Ref" doesn't increase this counter, 
            but "Increment State" does!
          </p>
        </div>
      </div>

      <div style={styles.section}>
        <h2>Code Example</h2>
        <div style={styles.codeBlock}>
          <pre>{`// 1. Accessing DOM Elements
function DOMExample() {
  const inputRef = useRef(null);
  
  const focusInput = () => {
    inputRef.current.focus();
  };
  
  return (
    <>
      <input ref={inputRef} type="text" />
      <button onClick={focusInput}>Focus</button>
    </>
  );
}

// 2. Storing Mutable Values
function CounterExample() {
  const countRef = useRef(0);
  
  const increment = () => {
    countRef.current += 1;
    console.log(countRef.current); // No re-render!
  };
  
  return <button onClick={increment}>Increment</button>;
}

// 3. Preserving Timer IDs
function TimerExample() {
  const intervalRef = useRef(null);
  
  useEffect(() => {
    intervalRef.current = setInterval(() => {
      console.log('tick');
    }, 1000);
    
    return () => clearInterval(intervalRef.current);
  }, []);
  
  return null;
}`}</pre>
        </div>
      </div>

      <div style={styles.section}>
        <h2>Common Use Cases</h2>
        <ul>
          <li><strong>Form Focus:</strong> Automatically focus input fields on mount or validation errors</li>
          <li><strong>Animations:</strong> Store animation frame IDs</li>
          <li><strong>Previous Values:</strong> Track previous state or prop values</li>
          <li><strong>Third-party Libraries:</strong> Store instances of non-React libraries (e.g., D3, maps)</li>
          <li><strong>Debounce/Throttle:</strong> Store timeout IDs for debounced functions</li>
        </ul>
      </div>
    </div>
  );
};

export default UseRefExample;
