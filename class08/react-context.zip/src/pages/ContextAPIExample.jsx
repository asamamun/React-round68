import { createContext, useContext, useState } from 'react';

// Create a Theme Context
const ThemeContext = createContext();

// Custom hook to use the theme context
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Theme Provider Component
export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Example Component that uses the theme
const ThemedComponent = () => {
  const { theme, toggleTheme } = useTheme();

  const styles = {
    container: {
      padding: '20px',
      backgroundColor: theme === 'light' ? '#ffffff' : '#333333',
      color: theme === 'light' ? '#333333' : '#ffffff',
      borderRadius: '8px',
      marginTop: '20px',
    },
    button: {
      padding: '10px 20px',
      backgroundColor: theme === 'light' ? '#007bff' : '#6c757d',
      color: '#ffffff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      marginTop: '10px',
    },
  };

  return (
    <div style={styles.container}>
      <h3>Themed Component</h3>
      <p>Current theme: <strong>{theme}</strong></p>
      <p>This component consumes the theme from Context API without passing props through every level.</p>
      <button onClick={toggleTheme} style={styles.button}>
        Toggle to {theme === 'light' ? 'Dark' : 'Light'} Theme
      </button>
    </div>
  );
};

// Nested Component to demonstrate prop drilling avoidance
const NestedComponent = () => {
  return (
    <div style={{ border: '2px solid #ccc', padding: '15px', borderRadius: '8px' }}>
      <h4>Nested Component</h4>
      <p>This is nested inside another component, but still has access to the theme!</p>
      <ThemedComponent />
    </div>
  );
};

const ContextAPIExample = () => {
  const styles = {
    container: {
      maxWidth: '800px',
      margin: '0 auto',
      padding: '20px',
    },
    header: {
      textAlign: 'center',
      marginBottom: '30px',
    },
    section: {
      marginBottom: '30px',
    },
    codeBlock: {
      backgroundColor: '#f4f4f4',
      padding: '15px',
      borderRadius: '5px',
      overflowX: 'auto',
      fontFamily: 'monospace',
      fontSize: '14px',
    },
  };

  return (
    <ThemeProvider>
      <div style={styles.container}>
        <h1 style={styles.header}>🔷 Context API Example</h1>
        
        <div style={styles.section}>
          <h2>Definition</h2>
          <p>
            The Context API provides a way to share values between components without having to 
            explicitly pass a prop through every level of the tree. It's designed to solve the 
            problem of "prop drilling" where data needs to be passed through multiple intermediate 
            components.
          </p>
        </div>

        <div style={styles.section}>
          <h2>Purpose</h2>
          <ul>
            <li><strong>Global State Management:</strong> Share data like themes, user authentication, or language preferences across your app</li>
            <li><strong>Avoid Prop Drilling:</strong> No need to pass props through multiple levels of components</li>
            <li><strong>Centralized Data:</strong> Keep related data in one place that all components can access</li>
            <li><strong>Better Code Maintainability:</strong> Easier to update and manage shared state</li>
          </ul>
        </div>

        <div style={styles.section}>
          <h2>Key Concepts</h2>
          <div style={styles.codeBlock}>
            <p><strong>1. React.createContext()</strong> - Creates a new context object</p>
            <p><strong>2. Context.Provider</strong> - Component that provides the context value to its children</p>
            <p><strong>3. useContext()</strong> - Hook to consume the context value in functional components</p>
            <p><strong>4. Context.Consumer</strong> - Alternative way to consume context (less common with hooks)</p>
          </div>
        </div>

        <div style={styles.section}>
          <h2>Live Example: Theme Switcher</h2>
          <p>Click the button below to toggle between light and dark themes. Notice how both the parent and nested components have access to the theme without any props being passed!</p>
          <NestedComponent />
        </div>

        <div style={styles.section}>
          <h2>Code Example</h2>
          <div style={styles.codeBlock}>
            <pre>{`// 1. Create Context
const ThemeContext = createContext();

// 2. Create Provider Component
function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light');
  
  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

// 3. Consume Context in Child Components
function ChildComponent() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  
  return (
    <div className={theme}>
      <p>Current theme: {theme}</p>
      <button onClick={toggleTheme}>Toggle Theme</button>
    </div>
  );
}`}</pre>
          </div>
        </div>
      </div>
    </ThemeProvider>
  );
};

export default ContextAPIExample;
