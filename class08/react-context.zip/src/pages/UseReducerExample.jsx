import { useReducer } from 'react';

// Reducer function that handles all state transitions
const cartReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_ITEM':
      const existingItem = state.items.find(
        (item) => item.id === action.payload.id
      );
      
      if (existingItem) {
        return {
          ...state,
          items: state.items.map((item) =>
            item.id === action.payload.id
              ? { ...item, quantity: item.quantity + 1 }
              : item
          ),
        };
      }
      
      return {
        ...state,
        items: [...state.items, { ...action.payload, quantity: 1 }],
      };

    case 'REMOVE_ITEM':
      return {
        ...state,
        items: state.items.filter((item) => item.id !== action.payload),
      };

    case 'UPDATE_QUANTITY':
      return {
        ...state,
        items: state.items.map((item) =>
          item.id === action.payload.id
            ? { ...item, quantity: action.payload.quantity }
            : item
        ),
      };

    case 'CLEAR_CART':
      return {
        ...state,
        items: [],
      };

    default:
      throw new Error(`Unknown action type: ${action.type}`);
  }
};

// Initial state
const initialState = {
  items: [],
  totalItems: 0,
  totalPrice: 0,
};

const UseReducerExample = () => {
  const [cartState, dispatch] = useReducer(cartReducer, initialState);

  // Sample products
  const products = [
    { id: 1, name: 'Laptop', price: 999.99 },
    { id: 2, name: 'Headphones', price: 149.99 },
    { id: 3, name: 'Keyboard', price: 79.99 },
    { id: 4, name: 'Mouse', price: 49.99 },
  ];

  const addToCart = (product) => {
    dispatch({ type: 'ADD_ITEM', payload: product });
  };

  const removeFromCart = (productId) => {
    dispatch({ type: 'REMOVE_ITEM', payload: productId });
  };

  const updateQuantity = (productId, quantity) => {
    if (quantity > 0) {
      dispatch({ type: 'UPDATE_QUANTITY', payload: { id: productId, quantity } });
    }
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
  };

  // Calculate totals
  const totalItems = cartState.items.reduce(
    (sum, item) => sum + item.quantity,
    0
  );
  const totalPrice = cartState.items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const styles = {
    container: {
      maxWidth: '1000px',
      margin: '0 auto',
      padding: '20px',
    },
    header: {
      textAlign: 'center',
      marginBottom: '30px',
    },
    section: {
      marginBottom: '30px',
    },
    codeBlock: {
      backgroundColor: '#f4f4f4',
      padding: '15px',
      borderRadius: '5px',
      overflowX: 'auto',
      fontFamily: 'monospace',
      fontSize: '14px',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      marginTop: '20px',
    },
    card: {
      border: '2px solid #ddd',
      borderRadius: '8px',
      padding: '15px',
      backgroundColor: '#fff',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    },
    button: {
      padding: '10px 20px',
      backgroundColor: '#007bff',
      color: '#ffffff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      marginRight: '5px',
      marginTop: '10px',
    },
    dangerButton: {
      padding: '10px 20px',
      backgroundColor: '#dc3545',
      color: '#ffffff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      marginRight: '5px',
      marginTop: '10px',
    },
    successButton: {
      padding: '10px 20px',
      backgroundColor: '#28a745',
      color: '#ffffff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      marginTop: '10px',
    },
    infoBox: {
      backgroundColor: '#e7f3ff',
      padding: '15px',
      borderRadius: '5px',
      borderLeft: '4px solid #007bff',
      marginBottom: '20px',
    },
    cartItem: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px',
      borderBottom: '1px solid #eee',
    },
    quantityControl: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    },
    input: {
      width: '50px',
      padding: '5px',
      textAlign: 'center',
      border: '1px solid #ccc',
      borderRadius: '4px',
    },
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>🔄 useReducer Hook Example</h1>

      <div style={styles.section}>
        <h2>Definition</h2>
        <p>
          The useReducer hook is an alternative to useState for managing complex state logic. 
          It's optimized for components where multiple sub-values or complex state transitions 
          are involved. It follows the Redux pattern and accepts a reducer function and initial 
          state, returning the current state and a dispatch function.
        </p>
      </div>

      <div style={styles.section}>
        <h2>Purpose</h2>
        <ul>
          <li><strong>Complex State Logic:</strong> Handle state with multiple sub-values or dependencies</li>
          <li><strong>Predictable State Transitions:</strong> Centralize state updates through actions</li>
          <li><strong>Better Testing:</strong> Easier to test pure reducer functions in isolation</li>
          <li><strong>Performance Optimization:</strong> Avoid unnecessary re-renders in deeply nested components</li>
          <li><strong>Maintainability:</strong> Keep related state logic together in one place</li>
        </ul>
      </div>

      <div style={styles.infoBox}>
        <strong>⚛️ When to use useReducer vs useState:</strong>
        <br />
        ✓ Use <strong>useState</strong> for simple, independent values
        <br />
        ✓ Use <strong>useReducer</strong> when state has multiple sub-values or next state depends on previous state
      </div>

      <div style={styles.section}>
        <h2>Key Concepts</h2>
        <div style={styles.codeBlock}>
          <p><strong>1. Reducer Function:</strong> Pure function that takes (state, action) and returns new state</p>
          <p><strong>2. Action:</strong> Object with a <code>type</code> property describing what happened</p>
          <p><strong>3. Dispatch:</strong> Function to send actions to the reducer</p>
          <p><strong>4. Initial State:</strong> Starting value for your state</p>
        </div>
      </div>

      <div style={styles.section}>
        <h2>Live Example: Shopping Cart</h2>
        <p>A complete shopping cart implementation using useReducer with add, remove, update, and clear functionality.</p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '20px' }}>
          {/* Products Section */}
          <div style={styles.card}>
            <h3>📦 Products</h3>
            <div style={styles.grid}>
              {products.map((product) => (
                <div
                  key={product.id}
                  style={{
                    border: '1px solid #ddd',
                    padding: '10px',
                    borderRadius: '5px',
                  }}
                >
                  <h4>{product.name}</h4>
                  <p style={{ color: '#28a745', fontWeight: 'bold' }}>
                    ${product.price.toFixed(2)}
                  </p>
                  <button
                    onClick={() => addToCart(product)}
                    style={styles.button}
                  >
                    Add to Cart
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Cart Section */}
          <div style={styles.card}>
            <h3>🛒 Shopping Cart ({totalItems} items)</h3>
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {cartState.items.length === 0 ? (
                <p style={{ color: '#666', fontStyle: 'italic' }}>
                  Your cart is empty
                </p>
              ) : (
                <>
                  {cartState.items.map((item) => (
                    <div key={item.id} style={styles.cartItem}>
                      <div>
                        <strong>{item.name}</strong>
                        <br />
                        <small>${item.price.toFixed(2)}</small>
                      </div>
                      <div style={styles.quantityControl}>
                        <button
                          onClick={() =>
                            updateQuantity(item.id, item.quantity - 1)
                          }
                          style={{ ...styles.button, padding: '5px 10px' }}
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) =>
                            updateQuantity(item.id, parseInt(e.target.value))
                          }
                          style={styles.input}
                          min="1"
                        />
                        <button
                          onClick={() =>
                            updateQuantity(item.id, item.quantity + 1)
                          }
                          style={{ ...styles.button, padding: '5px 10px' }}
                        >
                          +
                        </button>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          style={styles.dangerButton}
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                  <div
                    style={{
                      marginTop: '20px',
                      paddingTop: '15px',
                      borderTop: '2px solid #333',
                    }}
                  >
                    <h3>Total: ${totalPrice.toFixed(2)}</h3>
                    <button onClick={clearCart} style={styles.dangerButton}>
                      Clear Cart
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div style={styles.section}>
        <h2>Code Example</h2>
        <div style={styles.codeBlock}>
          <pre>{`// 1. Define Reducer Function
function cartReducer(state, action) {
  switch (action.type) {
    case 'ADD_ITEM':
      return {
        ...state,
        items: [...state.items, action.payload]
      };
    case 'REMOVE_ITEM':
      return {
        ...state,
        items: state.items.filter(
          item => item.id !== action.payload
        )
      };
    case 'CLEAR_CART':
      return { items: [] };
    default:
      throw new Error('Unknown action');
  }
}

// 2. Use in Component
function ShoppingCart() {
  const [cart, dispatch] = useReducer(cartReducer, initialState);
  
  const addItem = (product) => {
    dispatch({ type: 'ADD_ITEM', payload: product });
  };
  
  const removeItem = (id) => {
    dispatch({ type: 'REMOVE_ITEM', payload: id });
  };
  
  return (
    <div>
      {cart.items.map(item => (
        <div key={item.id}>
          {item.name}
          <button onClick={() => removeItem(item.id)}>
            Remove
          </button>
        </div>
      ))}
    </div>
  );
}`}</pre>
        </div>
      </div>

      <div style={styles.section}>
        <h2>Common Use Cases</h2>
        <ul>
          <li><strong>Forms:</strong> Complex form state with multiple fields and validation</li>
          <li><strong>Shopping Carts:</strong> Managing cart items, quantities, and totals</li>
          <li><strong>Multi-step Wizards:</strong> Track progress and data across multiple steps</li>
          <li><strong>Data Fetching:</strong> Handle loading, success, and error states</li>
          <li><strong>Game State:</strong> Manage game board, scores, and player turns</li>
        </ul>
      </div>
    </div>
  );
};

export default UseReducerExample;
