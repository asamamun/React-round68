import { Link } from 'react-router-dom';

const Home = () => {
  const styles = {
    container: {
      maxWidth: '900px',
      margin: '0 auto',
      padding: '40px 20px',
      textAlign: 'center',
    },
    header: {
      fontSize: '48px',
      marginBottom: '20px',
      color: '#333',
    },
    subtitle: {
      fontSize: '20px',
      color: '#666',
      marginBottom: '50px',
    },
    cardsContainer: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
      gap: '30px',
      marginTop: '40px',
    },
    card: {
      backgroundColor: '#fff',
      borderRadius: '12px',
      padding: '30px',
      boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
      cursor: 'pointer',
      border: '2px solid transparent',
    },
    cardHover: {
      transform: 'translateY(-5px)',
      boxShadow: '0 8px 12px rgba(0,0,0,0.15)',
      borderColor: '#007bff',
    },
    icon: {
      fontSize: '64px',
      marginBottom: '20px',
    },
    cardTitle: {
      fontSize: '24px',
      marginBottom: '15px',
      color: '#333',
    },
    cardDescription: {
      fontSize: '16px',
      color: '#666',
      lineHeight: '1.6',
      marginBottom: '20px',
    },
    linkButton: {
      display: 'inline-block',
      padding: '12px 24px',
      backgroundColor: '#007bff',
      color: '#fff',
      textDecoration: 'none',
      borderRadius: '6px',
      fontWeight: 'bold',
      transition: 'background-color 0.3s ease',
    },
  };

  const examples = [
    {
      icon: '🔷',
      title: 'Context API',
      description:
        'Learn how to share data across components without prop drilling. Perfect for themes, authentication, and global state management.',
      path: '/context-api',
      color: '#61dafb',
    },
    {
      icon: '📌',
      title: 'useRef Hook',
      description:
        'Master DOM manipulation and mutable references that persist across renders without triggering re-renders.',
      path: '/use-ref',
      color: '#ff6b6b',
    },
    {
      icon: '🔄',
      title: 'useReducer Hook',
      description:
        'Handle complex state logic with predictable state transitions. Ideal for shopping carts, forms, and multi-step wizards.',
      path: '/use-reducer',
      color: '#51cf66',
    },
  ];

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>React Hooks & Context Examples</h1>
      <p style={styles.subtitle}>
        Interactive demonstrations of three powerful React features
      </p>

      <div style={styles.cardsContainer}>
        {examples.map((example, index) => (
          <div
            key={index}
            style={styles.card}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = styles.cardHover.transform;
              e.currentTarget.style.boxShadow = styles.cardHover.boxShadow;
              e.currentTarget.style.borderColor = example.color;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = styles.card.boxShadow;
              e.currentTarget.style.borderColor = 'transparent';
            }}
          >
            <div style={{ ...styles.icon, color: example.color }}>{example.icon}</div>
            <h2 style={styles.cardTitle}>{example.title}</h2>
            <p style={styles.cardDescription}>{example.description}</p>
            <Link to={example.path} style={{ ...styles.linkButton, backgroundColor: example.color }}>
              View Example →
            </Link>
          </div>
        ))}
      </div>

      <div
        style={{
          marginTop: '60px',
          padding: '30px',
          backgroundColor: '#f8f9fa',
          borderRadius: '12px',
        }}
      >
        <h3 style={{ marginBottom: '15px' }}>📚 What You'll Learn</h3>
        <ul
          style={{
            textAlign: 'left',
            maxWidth: '600px',
            margin: '0 auto',
            lineHeight: '2',
          }}
        >
          <li>✅ Understanding Context API and when to use it</li>
          <li>✅ Mastering useRef for DOM access and mutable values</li>
          <li>✅ Implementing useReducer for complex state management</li>
          <li>✅ Live, interactive examples you can experiment with</li>
          <li>✅ Best practices and real-world use cases</li>
        </ul>
      </div>
    </div>
  );
};

export default Home;
