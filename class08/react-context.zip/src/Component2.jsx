import Component3 from './Component3.jsx';
import { useContext } from 'react';
import { UserContext } from './Appp.jsx';

const Component2 = () => {
    const { user, color } = useContext(UserContext);
    return (
        <div>
            <h1>Hello from Component2</h1>
            <p>component2 : {user}</p>
            <p>component2 : {color}</p>
            <Component3 />
        </div>
    );
};
export default Component2;
