import { useContext } from 'react';
import { UserContext } from './Appp.jsx';
const Component3 = () => {
    const { user, color } = useContext(UserContext);
    return (
        <div>
            <h1>Hello from Component3</h1>
            <p>Component3: {user}</p>
            <p>Component3: {color}</p>


        </div>
    );
};
export default Component3;
